#include<bits/stdc++.h>
#include<windows.h>
using namespace std;
int thread_number;
int two_wc,two_wc_sieve;
int two_fc,two_fc_sieve;
int two_xp,two_xp_sieve;
int xp_sieve,xp_potential_sieve;
int fp_sieve,fp_potential_sieve;
int cp_sieve,cp_potential_sieve;
int dp_sieve,dp_potential_sieve;
string command="";
void SYSTEM(string s)
{
    system(s.c_str());
}
int main()
{
    cerr<<"Reading config.\n";
    freopen("config.txt","r",stdin);
    cin>>xp_sieve>>xp_potential_sieve;
    cin>>fp_sieve>>fp_potential_sieve;
    cin>>cp_sieve>>cp_potential_sieve;
    cin>>dp_sieve>>dp_potential_sieve;

    cin>>thread_number;

    cin>>two_fc>>two_fc_sieve;
    cin>>two_wc>>two_wc_sieve;
    cin>>two_xp>>two_xp_sieve;

    cerr<<"Clear tmp folder.\n";system("rmdir /s /q tmp");system("mkdir tmp");

    cerr<<"merge files.\n";system("merge_files.bat");
    cerr<<"duplicate.\n";system("duplicate.exe ./tmp/new.txt ./file/old.txt ./tmp/new_dup.txt");Sleep(1000);
    cerr<<"divide new.\n";    system("divide.exe ./tmp/new_dup.txt ./tmp/new_1.txt ./tmp/new_2.txt");

    
    cerr<<"Get useful names.\n";

    cerr<<"FP and FP potential.\n";
    command="SP_potential.exe 1 " +to_string(thread_number) +" ./tmp/new_1.txt ./tmp/new_tmp.txt";system(command.c_str());
    command="select.exe " +to_string(fp_sieve)+" "+to_string(fp_potential_sieve)+" ./tmp/new_tmp.txt ./tmp/new_fz.txt ./tmp/new_left.txt";system(command.c_str());


    cerr<<"CP and CP potential.\n";
    command="SP_potential.exe 2 " +to_string(thread_number) +" ./tmp/new_2.txt ./tmp/new_tmp.txt";system(command.c_str());
    command="select.exe " +to_string(cp_sieve)+" "+to_string(cp_potential_sieve)+" ./tmp/new_tmp.txt ./tmp/new_bc.txt ./tmp/new_left.txt";system(command.c_str());

    
    cerr<<"DP and DP potential.\n";
    command="SP_potential.exe 3 " +to_string(thread_number) +" ./tmp/new_1.txt ./tmp/new_tmp.txt";system(command.c_str());
    command="select.exe " +to_string(dp_sieve)+" "+to_string(dp_potential_sieve)+" ./tmp/new_tmp.txt ./tmp/new_wc.txt ./tmp/new_left.txt";system(command.c_str());

    cerr<<"XP and XP potential 1.\n";
    command="XP_potential.exe " +to_string(thread_number) +" ./tmp/new_1.txt ./tmp/new_tmp.txt";system(command.c_str());
    command="select.exe " +to_string(xp_sieve)+" "+to_string(xp_potential_sieve)+" ./tmp/new_tmp.txt ./tmp/new_1.txt ./tmp/new_left.txt";system(command.c_str());
    
    cerr<<"XP and XP potential 2.\n";
    command="XP_potential.exe " +to_string(thread_number) +" ./tmp/new_2.txt ./tmp/new_tmp.txt";system(command.c_str());
    command="select.exe " +to_string(xp_sieve)+" "+to_string(xp_potential_sieve)+" ./tmp/new_tmp.txt ./tmp/new_2.txt ./tmp/new_left.txt";system(command.c_str());
    


    cerr<<"XP new_1.\n";      system("XP.exe ./tmp/new_1.txt ./tmp/new_xp_1.txt");
    cerr<<"XP new_2.\n";      system("XP.exe ./tmp/new_2.txt ./tmp/new_xp_2.txt");
    cerr<<"SP FZ.\n";         system("SP.exe 1 ./tmp/new_fz.txt ./tmp/new_fz_score.txt");
    cerr<<"SP BC.\n";         system("SP.exe 2 ./tmp/new_bc.txt ./tmp/new_bc_score.txt");
    cerr<<"SP WC.\n";         system("SP.exe 3 ./tmp/new_wc.txt ./tmp/new_wc_score.txt");
    cerr<<"sort new_1.\n";    system("sort.exe 0 ./tmp/new_xp_1.txt ./tmp/new_1.txt");
    cerr<<"sort new_2.\n";    system("sort.exe 0 ./tmp/new_xp_2.txt ./tmp/new_2.txt");
    cerr<<"sort FZ.\n";       system("sort.exe 0 ./tmp/new_fz_score.txt ./tmp/new_fz.txt");
    cerr<<"sort BC.\n";       system("sort.exe 0 ./tmp/new_bc_score.txt ./tmp/new_bc.txt");
    cerr<<"sort WC.\n";       system("sort.exe 0 ./tmp/new_wc_score.txt ./tmp/new_wc.txt");


    if (two_fc)
    {
        cerr<<"two_fc new_fz new_bc\n";command="two_FC.exe 1 "+to_string(thread_number)+" "+to_string(two_fc_sieve)+" ./tmp/new_fz.txt ./tmp/new_bc.txt ./out/FC.txt";system(command.c_str());
        cerr<<"two_fc new_fz old_bc\n";command="two_FC.exe 1 "+to_string(thread_number)+" "+to_string(two_fc_sieve)+" ./tmp/new_fz.txt ./file/old_bc.txt ./out/FC.txt";system(command.c_str());
        cerr<<"two_fc old_fz new_bc\n";command="two_FC.exe 1 "+to_string(thread_number)+" "+to_string(two_fc_sieve)+" ./file/old_fz.txt ./tmp/new_bc.txt ./out/FC.txt";system(command.c_str());
    }
    if (two_wc)
    {
        cerr<<"two_wc new_wc new_wc\n";command="two_WC.exe 0 "+to_string(thread_number)+" "+to_string(two_wc_sieve)+" ./tmp/new_wc.txt ./tmp/blank.txt ./out/WC.txt";system(command.c_str());
        cerr<<"two_wc new_wc old_wc\n";command="two_WC.exe 1 "+to_string(thread_number)+" "+to_string(two_wc_sieve)+" ./tmp/new_wc.txt ./file/old_wc.txt ./out/WC.txt";system(command.c_str());
    }
    if (two_xp)
    {
        cerr<<"two_xp new_1 new_1\n";command="two_XP.exe 0 "+to_string(thread_number)+" "+to_string(two_xp_sieve)+" ./tmp/new_1.txt ./tmp/blank.txt ./out/XP.txt";system(command.c_str());
        cerr<<"two_xp new_1 new_2\n";command="two_XP.exe 1 "+to_string(thread_number)+" "+to_string(two_xp_sieve)+" ./tmp/new_1.txt ./tmp/new_2.txt ./out/XP.txt";system(command.c_str());
        cerr<<"two_xp new_1 old_1\n";command="two_XP.exe 1 "+to_string(thread_number)+" "+to_string(two_xp_sieve)+" ./tmp/new_1.txt ./file/old_1.txt ./out/XP.txt";system(command.c_str());
        cerr<<"two_xp new_1 old_2\n";command="two_XP.exe 1 "+to_string(thread_number)+" "+to_string(two_xp_sieve)+" ./tmp/new_1.txt ./file/old_2.txt ./out/XP.txt";system(command.c_str());
        cerr<<"two_xp old_1 new_2\n";command="two_XP.exe 1 "+to_string(thread_number)+" "+to_string(two_xp_sieve)+" ./file/old_1.txt ./tmp/new_2.txt ./out/XP.txt";system(command.c_str());
    }


    cerr<<"COPY to file\n";
    system("move.exe ./tmp/new_dup.txt ./file/old.txt");
    system("move.exe ./tmp/new_1.txt ./file/old_1.txt");
    system("move.exe ./tmp/new_2.txt ./file/old_2.txt");
    system("move.exe ./tmp/new_fz.txt ./file/old_fz.txt");
    system("move.exe ./tmp/new_bc.txt ./file/old_bc.txt");
    system("move.exe ./tmp/new_wc.txt ./file/old_wc.txt");

    cerr<<"XP old_1.\n";      system("XP.exe ./file/old_1.txt ./file/old_xp_1.txt");
    cerr<<"XP old_2.\n";      system("XP.exe ./file/old_2.txt ./file/old_xp_2.txt");
    cerr<<"SP FZ.\n";         system("SP.exe 1 ./file/old_fz.txt ./file/old_fz_score.txt");
    cerr<<"SP BC.\n";         system("SP.exe 2 ./file/old_bc.txt ./file/old_bc_score.txt");
    cerr<<"SP WC.\n";         system("SP.exe 3 ./file/old_wc.txt ./file/old_wc_score.txt");
    cerr<<"SP DT.\n";         system("SP.exe 4 ./file/old.txt ./file/old_dt_score.txt");
    cerr<<"sort old_1.\n";    system("sort.exe 0 ./file/old_xp_1.txt ./file/old_1.txt");system("sort.exe 1 ./file/old_xp_1.txt ./file/old_xp_1.txt");
    cerr<<"sort old_2.\n";    system("sort.exe 0 ./file/old_xp_2.txt ./file/old_2.txt");system("sort.exe 1 ./file/old_xp_2.txt ./file/old_xp_2.txt");
    cerr<<"sort FZ.\n";       system("sort.exe 0 ./file/old_fz_score.txt ./file/old_fz.txt");system("sort.exe 1 ./file/old_fz_score.txt ./file/old_fz_score.txt");
    cerr<<"sort BC.\n";       system("sort.exe 0 ./file/old_bc_score.txt ./file/old_bc.txt");system("sort.exe 1 ./file/old_bc_score.txt ./file/old_bc_score.txt");
    cerr<<"sort WC.\n";       system("sort.exe 0 ./file/old_wc_score.txt ./file/old_wc.txt");system("sort.exe 1 ./file/old_wc_score.txt ./file/old_wc_score.txt");
    cerr<<"sort DT.\n";       system("sort.exe 0 ./file/old_dt_score.txt ./file/old_dt.txt"); system("sort.exe 1 ./file/old_dt_score.txt ./file/old_dt_score.txt");
    //system("type ./tmp/new.txt >> ./file/old.txt");
    
    cerr<<"COPY to new\n";
    system("move.exe ./tmp/new_dup.txt ./new/new.txt");
    system("move.exe ./tmp/new_1.txt ./new/new_1.txt");
    system("move.exe ./tmp/new_2.txt ./new/new_2.txt");
    system("move.exe ./tmp/new_fz.txt ./new/new_fz.txt");
    system("move.exe ./tmp/new_bc.txt ./new/new_bc.txt");
    system("move.exe ./tmp/new_wc.txt ./new/new_wc.txt");

    cerr<<"XP old_1.\n";      system("XP.exe ./new/new_1.txt ./new/new_xp_1.txt");
    cerr<<"XP old_2.\n";      system("XP.exe ./new/new_2.txt ./new/new_xp_2.txt");
    cerr<<"SP FZ.\n";         system("SP.exe 1 ./new/new_fz.txt ./new/new_fz_score.txt");
    cerr<<"SP BC.\n";         system("SP.exe 2 ./new/new_bc.txt ./new/new_bc_score.txt");
    cerr<<"SP WC.\n";         system("SP.exe 3 ./new/new_wc.txt ./new/new_wc_score.txt");
    cerr<<"SP DT.\n";         system("SP.exe 4 ./new/new.txt ./new/new_dt_score.txt");
    cerr<<"sort old_1.\n";    system("sort.exe 0 ./new/new_xp_1.txt ./new/new_1.txt");system("sort.exe 1 ./new/new_xp_1.txt ./new/new_xp_1.txt");
    cerr<<"sort old_2.\n";    system("sort.exe 0 ./new/new_xp_2.txt ./new/new_2.txt");system("sort.exe 1 ./new/new_xp_2.txt ./new/new_xp_2.txt");
    cerr<<"sort FZ.\n";       system("sort.exe 0 ./new/new_fz_score.txt ./new/new_fz.txt");system("sort.exe 1 ./new/new_fz_score.txt ./new/new_fz_score.txt");
    cerr<<"sort BC.\n";       system("sort.exe 0 ./new/new_bc_score.txt ./new/new_bc.txt");system("sort.exe 1 ./new/new_bc_score.txt ./new/new_bc_score.txt");
    cerr<<"sort WC.\n";       system("sort.exe 0 ./new/new_wc_score.txt ./new/new_wc.txt");system("sort.exe 1 ./new/new_wc_score.txt ./new/new_wc_score.txt");
    cerr<<"sort DT.\n";       system("sort.exe 0 ./new/new_dt_score.txt ./new/new_dt.txt"); system("sort.exe 1 ./new/new_dt_score.txt ./new/new_dt_score.txt");

}