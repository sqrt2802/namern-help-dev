#include <pthread.h>
#include <windows.h>
#include <algorithm>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <iostream>
#include <random>
#include <vector>
#include <unordered_map>
#pragma GCC optimize("Ofast")
#pragma GCC target("sse,sse2,sse3,ssse3,sse4,abm,mmx,avx,avx2")
#pragma GCC optimize("unroll-loops")
typedef unsigned long long u64_t;
typedef unsigned char u8_t;
using namespace std;
const char PRE = 'S';
int XPmin = 4900, XDmin = 5700, XD_XPmin = 3500;
int tot_1,tot_2;
vector<int> last_list;
const char skillNameMap[][13] = {
        "火球术", "冰冻术",     "雷击术",     "地裂术",     "吸血攻击", "投毒",
        "连击",     "会心一击", "瘟疫",         "生命之轮", "狂暴术",     "魅惑",
        "加速术", "减速术",     "诅咒",         "治愈魔法", "苏生术",     "净化",
        "铁壁",     "蓄力",         "聚气",         "潜行",         "血祭",         "分身",
        "幻术",     "防御",         "守护",         "伤害反弹", "护身符",     "护盾",
        "反击",     "吞噬",         "召唤亡灵", "垂死抗争", "隐匿",         "啧",
        "啧",         "啧",             "啧",             "啧"};
string skillNameMap_2[35] = {
        "火球", "冰冻", "雷击", "地裂", "吸血", "投毒", "连击", "会心", "瘟疫",
        "命轮", "狂暴", "魅惑", "加速", "减速", "诅咒", "治愈", "苏生", "净化",
        "铁壁", "蓄力", "聚气", "潜行", "血祭", "分身", "幻术", "防御", "守护",
        "反弹", "护符", "护盾", "反击", "吞噬", "召灵", "垂死", "隐匿"};
const int N = 256, M = 128, K = 64, skill_cnt = 40,base=13331;
int type;


char *dvt(char *p) {
    DWORD dwNum = MultiByteToWideChar(CP_UTF8, 0, p, -1, NULL, 0);
    char *psText;
    wchar_t *pwText = (wchar_t *)malloc(dwNum * sizeof(wchar_t));
    dwNum = MultiByteToWideChar(CP_UTF8, 0, p, -1, pwText, dwNum);
    dwNum = WideCharToMultiByte(CP_ACP, 0, pwText, -1, NULL, 0, NULL, NULL);
    psText = (char *)malloc(dwNum * sizeof(char));
    dwNum = WideCharToMultiByte(CP_ACP, 0, pwText, -1, psText, dwNum, NULL, NULL);
    free(pwText);
    return psText;
}

int thread_number=30;
char OOO[1024];
void puts_Chinese(string s_cn) {
    cout << s_cn;
    // for (int i=0;i<1023;i++) OOO[i]=s_cn[i];
    // char *PPP= dvt(OOO);
    // printf("%s",PPP);
}

struct Name {
    u8_t ual[N], val[N], val_base[N], val_base2[N];
    u8_t name_base[M], freq[16], skill[skill_cnt], p, q;
    u8_t last;
    double x[50];
    char NAME_SELF[N], TEAM_SELF[N];
    int q_len, seed, PRELEN, NAMELEN;
    float shadowi;
    inline u8_t m() {
        q += val[++p];
        swap(val[p], val[q]);
        return val[val[p] + val[q] & 255];
    }
    inline int gen() {
        int u = m();
        return (u << 8 | m()) % skill_cnt;
    }
    void load_team(char *_team) {
        int t_len = strlen(_team) + 1;
        u8_t s;
        for (int i = 0; i < N; i++) val_base[i] = i;
        for (int i = s = 0; i < N; ++i) {
            if (i % t_len) s += _team[i % t_len - 1];
            s += val_base[i];
            swap(val_base[i], val_base[s]);
        }
    }

#define median(x, y, z) \
    x < y ? (x < z ? (y < z ? y : z) : x) : (y < z ? (x < z ? x : z) : y)

    void loading_name(const char *name) {
        memcpy(val, val_base, sizeof val);
        q_len = -1;
        u8_t s;
        int t_len = strlen(name) + 1;
        for (int _ = 0; _ < 2; _++)
            for (int i = s = 0; i < N; i++) {
                if (i % t_len) s += name[i % t_len - 1];
                s += val[i];
                swap(val[i], val[s]);
            }
        for (int i = 0; i < N; i += 8) {
            ual[i + 0] = val[i + 0] * 181 + 160;
            ual[i + 1] = val[i + 1] * 181 + 160;
            ual[i + 2] = val[i + 2] * 181 + 160;
            ual[i + 3] = val[i + 3] * 181 + 160;
            ual[i + 4] = val[i + 4] * 181 + 160;
            ual[i + 5] = val[i + 5] * 181 + 160;
            ual[i + 6] = val[i + 6] * 181 + 160;
            ual[i + 7] = val[i + 7] * 181 + 160;
        }
        for (int i = 0; i < N; i++)
            if (ual[i] >= 89 && ual[i] < 217) name_base[++q_len] = ual[i] & 63;
        for (int i = 0; i < skill_cnt; i++) skill[i] = i;
        memset(freq, 0, sizeof freq);

        p = q = 0;
        for (int s = 0, _ = 0; _ < 2; _++)
            for (int i = 0; i < skill_cnt; i++) {
                s = (s + gen() + skill[i]) % skill_cnt;
                swap(skill[i], skill[s]);
            }
    }
    void get_43() {
        sort(name_base, name_base + 10);
        memset(x, 0, sizeof(x));
        x[0] = 154 + name_base[3] + name_base[4] + name_base[5] + name_base[6];
        x[1] = 36 + (median(name_base[10], name_base[11], name_base[12]));
        x[2] = 36 + (median(name_base[13], name_base[14], name_base[15]));
        x[3] = 36 + (median(name_base[16], name_base[17], name_base[18]));
        x[4] = 36 + (median(name_base[19], name_base[20], name_base[21]));
        x[5] = 36 + (median(name_base[22], name_base[23], name_base[24]));
        x[6] = 36 + (median(name_base[25], name_base[26], name_base[27]));
        x[7] = 36 + (median(name_base[28], name_base[29], name_base[30]));
        u8_t *a = name_base + K;
        
        if (last == 254) {
            last = -1;
            for (int i = 0, j = 0; i < K; i += 4, j++) {
                u8_t p = min({a[i], a[i + 1], a[i + 2], a[i + 3]});
                if (p > 10 && skill[j] < 35) {
                    freq[j] = p - 10;
                    if (skill[j] < 25) last = j;
                } else
                    freq[j] = 0;
            }
        } else {
            for (int i = 0, j = 0; i < K; i += 4, j++) {
                u8_t p = min({a[i], a[i + 1], a[i + 2], a[i + 3]});
                if (p > 10 && skill[j] < 35) {
                    freq[j] = p - 10;
                } else
                    freq[j] = 0;
            }
        }
        //cerr<<"last="<<(int)(last)<<"\n";
        if (last != -1) freq[last] <<= 1;
        if (freq[14] && last != 14)
            freq[14] += min({name_base[60], name_base[61], freq[14]});
        if (freq[15] && last != 15)
            freq[15] += min({name_base[62], name_base[63], freq[15]});
        double zd=1,kill=1,bd=1;
		for (int k=0;k<16;k++)
        {
            if (skill[k]==9 || skill[k]==16) //命轮苏生
            {
                x[skill[k]+8]=zd*freq[k];
                zd*=(1-freq[k]*0.3/128);
            }
            else if (skill[k]==18) //铁壁
            {
                
                x[skill[k]+8]=zd*freq[k];
                zd*=(1-freq[k]*0.35/128);
            }
            else if (skill[k]==19) //蓄力
            {
                
                x[skill[k]+8]=zd*freq[k];
                zd*=(1-freq[k]*0.6/128);
            }
            else if (skill[k]==20 || skill[k]==22) //聚气血祭
            {
                
                x[skill[k]+8]=zd*freq[k];
                zd*=(1-freq[k]*0.7/128);
            }
            else if (skill[k]<25) //一般主动
            {
                x[skill[k]+8]=zd*freq[k];
                zd*=(1-freq[k]*1.0/128);
            } else 
            if (skill[k]==31 || skill[k]==32)
            {
                x[skill[k]+8] = kill*freq[k];
                kill*=(1-freq[k]*1.0/128);
            } else x[skill[k]+8]=freq[k];
        }
        if (x[32] > 0)  x[43] = shadowi * 1.0 * x[32] / 100;
        else x[43] = 0;
        if (x[42] > 0) x[42] += 20;
    }
    void output_43()
    {
        sort(name_base, name_base + 10);
        memset(x, 0, sizeof(x));
        x[0] = 154 + name_base[3] + name_base[4] + name_base[5] + name_base[6];
        x[1] = 36 + (median(name_base[10], name_base[11], name_base[12]));
        x[2] = 36 + (median(name_base[13], name_base[14], name_base[15]));
        x[3] = 36 + (median(name_base[16], name_base[17], name_base[18]));
        x[4] = 36 + (median(name_base[19], name_base[20], name_base[21]));
        x[5] = 36 + (median(name_base[22], name_base[23], name_base[24]));
        x[6] = 36 + (median(name_base[25], name_base[26], name_base[27]));
        x[7] = 36 + (median(name_base[28], name_base[29], name_base[30]));
        u8_t *a = name_base + K;
        
        if (last == 254) {
            last = -1;
            for (int i = 0, j = 0; i < K; i += 4, j++) {
                u8_t p = min({a[i], a[i + 1], a[i + 2], a[i + 3]});
                if (p > 10 && skill[j] < 35) {
                    freq[j] = p - 10;
                    if (skill[j] < 25) last = j;
                } else
                    freq[j] = 0;
            }
        } else {
            for (int i = 0, j = 0; i < K; i += 4, j++) {
                u8_t p = min({a[i], a[i + 1], a[i + 2], a[i + 3]});
                if (p > 10 && skill[j] < 35) {
                    freq[j] = p - 10;
                } else
                    freq[j] = 0;
            }
        }
        //cerr<<"last="<<(int)(last)<<"\n";
        if (last != -1) freq[last] <<= 1;
        if (freq[14] && last != 14) freq[14] += min({name_base[60], name_base[61], freq[14]});
        if (freq[15] && last != 15) freq[15] += min({name_base[62], name_base[63], freq[15]});
	    //pthread_mutex_lock(&Mutex_Lock);
        for (int i=0;i<8;i++) printf("%d ",(int)(x[i]));
        for (int i = 0; i < 16; i++) if (freq[i])
        {
            cout<<skillNameMap_2[skill[i]]<<":"<<(int)freq[i]<<" ";
            //x[skill[i] + 8] = freq[i];
        }
        cout<<"\n";
	    //pthread_mutex_unlock(&Mutex_Lock);
    }
};
void cpy(Name &x,Name &y)
{
    x.shadowi=y.shadowi;x.last=y.last;
    memcpy(x.name_base,y.name_base,sizeof(x.name_base));
    memcpy(x.skill,y.skill,sizeof(x.skill));
}
int n, prelen, tp;
long long l, r;
u8_t idx[16];
Name name_initial;
int pos[45],pos2[45][45];
void init_poly()
{
    int l, i, p, q, j;
    double r;
    for (int y = 0; y < 1034; y++) {
        l = 44;
        i = 0, p = 0, q = 0;
        r = 0;
        j = y;
        for (int k = 0; k < 45; k++) {
            i++, p += (i > 2), q = j, j = j - l + p;
            if (j < 0) break;
        }
        if (i == 1) pos[q] = y+1;
        if (i > 1) pos2[p][p+q] = pos2[p+q][p] = y+1;
    }
}
void hanxu_Poly(double *xp, double *x) {
    int l, i, p, q, j;
    double r;
    for (int y = 0; y < 1034; y++) {
        l = 44;
        i = 0, p = 0, q = 0;
        r = 0;
        j = y;
        for (int k = 0; k < 45; k++) {
            i++, p += (i > 2), q = j, j = j - l + p;
            if (j < 0) break;
        }
        if (i == 1) r = x[q];
        if (i > 1) r = x[p] * x[p + q];
        xp[y] = r;
    }
}
char NAME_SHADOW[N];
int prop[8];
char NAME_ALL[N], TEAM[N], NAME[N], NAME_ALL2[N];
void cvt_name() {
    int len = MultiByteToWideChar(CP_ACP, 0, NAME_ALL2, -1, NULL, 0);
    wchar_t *wstr = new wchar_t[len + 1];
    memset(wstr, 0, len + 1);
    MultiByteToWideChar(CP_ACP, 0, NAME_ALL2, -1, wstr, len);
    len = WideCharToMultiByte(CP_UTF8, 0, wstr, -1, NULL, 0, NULL, NULL);
    memset(NAME_ALL, 0, len + 1);
    WideCharToMultiByte(CP_UTF8, 0, wstr, -1, NAME_ALL, len, NULL, NULL);
    if (wstr) delete[] wstr;
}
Name name, name2;
int tot_cnt = 0;
struct Skill {
    int freq, id;
};
vector<Skill> vec;
bool cmp(Skill a, Skill b) {
    return a.freq == b.freq ? a.id < b.id : a.freq > b.freq;
}
vector<Name> name_list;


int TYPE=0;

int min_sumxp;
int main(int argc, char* argv[]) {
    if (argc != 4) {
        std::cerr << "Usage: " << argv[0] << " <input_file> <output_file_1> <output_file_2>" << std::endl;
        return 1;
    }
    freopen(argv[1],"r",stdin);
    FILE *fp1=fopen(argv[2],"w");
    FILE *fp2=fopen(argv[3],"w");
    
    Name X;
    double xp_array[1034], xp_x[44], score;
    vector<int> pos_dt;
    int total_cnt=0;
    while (1) 
    {
        total_cnt++;
        if (total_cnt%10000==0) cerr<<"cnt="<<total_cnt<<"\n";
        memset(NAME_ALL, 0, sizeof(NAME_ALL));
        char *read_p = NAME_ALL;
        int tot = 0;
        bool flag_out = 0;
        while ((*read_p = getchar()) == '\n') {
            tot++;
            if (tot == 100) {
                flag_out = 1;
                break;
            }
        }
        tot = 0;
        while ((*++read_p = getchar()) != '\n') {
            tot++;
            if (tot == 100) {
                flag_out = 1;
                break;
            }
        }
        *read_p = 0;
        if (flag_out == 1) break;
        memset(NAME, 0, sizeof(NAME));
        memset(TEAM, 0, sizeof(TEAM));
        int p = -1;
        for (int i = 0; i < N; i++)
            if (NAME_ALL[i] == '@') p = i;
        for (int i = p + 1; i < N; i++) TEAM[i - p - 1] = NAME_ALL[i];
        if (p != -1)
            for (int i = 0; i < p; i++) NAME[i] = NAME_ALL[i];
        else
            for (int i = 0; i < N; i++) NAME[i] = NAME_ALL[i];
        name.load_team(TEAM);
        name.loading_name(NAME);
        for (int i = 0; i < N; i++) name.NAME_SELF[i] = NAME_ALL[i];
        for (int i = 0; i < N; i++) name.TEAM_SELF[i] = TEAM[i];
        for (int _ = 0; _ < N; _++) NAME_SHADOW[_] = NAME[_];
        int NAME_LEN = strlen(NAME_SHADOW);
        // cerr<<NAME_LEN<<'\n';
        NAME_SHADOW[NAME_LEN] = '?';
        NAME_SHADOW[NAME_LEN + 1] = 's';
        NAME_SHADOW[NAME_LEN + 2] = 'h';
        NAME_SHADOW[NAME_LEN + 3] = 'a';
        NAME_SHADOW[NAME_LEN + 4] = 'd';
        NAME_SHADOW[NAME_LEN + 5] = 'o';
        NAME_SHADOW[NAME_LEN + 6] = 'w';
        NAME_SHADOW[NAME_LEN + 7] = 0;
        name2 = name;
        name2.loading_name(NAME_SHADOW);
        prop[0] = median(name2.name_base[10], name2.name_base[11], name2.name_base[12]);
        prop[1] = median(name2.name_base[13], name2.name_base[14], name2.name_base[15]);
        prop[2] = median(name2.name_base[16], name2.name_base[17], name2.name_base[18]);
        prop[3] = median(name2.name_base[19], name2.name_base[20], name2.name_base[21]);
        prop[4] = median(name2.name_base[22], name2.name_base[23], name2.name_base[24]);
        prop[5] = median(name2.name_base[25], name2.name_base[26], name2.name_base[27]);
        prop[6] = median(name2.name_base[28], name2.name_base[29], name2.name_base[30]);
        prop[7] = 154 + name2.name_base[3] + name2.name_base[4] +
                            name2.name_base[5] + name2.name_base[6];
        float shadowi = prop[0]*2.8+prop[1]*0.6+prop[2]*2.5+prop[3]*1.2+prop[4]+prop[5]-1.2*prop[6]+0.8*prop[7];
        name.shadowi = shadowi;
        Name tmp_name=name;
        tmp_name.last=-2;
        tmp_name.get_43();
        for (int i=0;i<44;i++) name.x[i]=tmp_name.x[i];

        cpy(X,name);
        double score_max=0;
        double bc_max=0;
        double bc_min=1000;
        int k_max=0;
        for (int k=31;k<64;k++)
        {
            X.last=tmp_name.last;
            if (k!=7) X.name_base[k]=63;
            X.get_43();
            bc_max=max(bc_max,X.x[29]);
            bc_min=min(bc_min,X.x[29]);
            X.name_base[k]=name.name_base[k];
        }
        if (bc_min<=20) fprintf(fp1,"%s\n",NAME_ALL);
        if (bc_max>=30) fprintf(fp2,"%s\n",NAME_ALL);
    }
	cerr<<"finish tasks.\n";
	fflush(stdout);
}
