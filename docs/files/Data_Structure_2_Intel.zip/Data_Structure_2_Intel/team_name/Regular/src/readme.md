~~假如你的电脑是 AMD 芯片，在运行该工具时可能会出现问题。请**在确保自己有 g++ 编译器的情况下**自行重新编译所有文件，编译命令应当加上 `-Ofast -unroll-loops -pthread`。或者双击运行我提供的 `compile.bat`。~~

我提供了 AMD 和 intel 双版本，请确认自己拿的是正确版本。必要情况下，尝试重新编译。

-----------------

省流：把存号的文件放到 `input` 文件夹，双击 `all.exe`，二人组结果在 `out` 里，如果想看单挑的话看 `file` 或者 `new` 文件夹的 `xxx_dt_score`，表示 SCQD。

`dt` 表示单挑，`fz` 表示辅助（配合背刺使用的），`bc` 表示背刺，`wc` 表示**传统**无刺（包括地裂瘟疫连击净化诅咒铁壁冰冻会心等等）。

该工具无法配出非传统无刺二人组，比如分身组合、魅惑组合。

-----------------
本工具为全套战队打理器。你应当对每一个战队开一个文件夹（复制里面的内容）。

如果你不想知道具体怎么运作的，那么你只需要关心 `config.txt`。  

打开 `config.txt`，里面有若干参数。  
默认如下：

```
5300 5700
4100 4500
4200 4600
4200 4600
12
1 9700
1 9500
1 12400
```

前八项分别表示 `xp` 阈值，`xp` 潜力阈值，以及 `sfp scp sdp` 的阈值和潜力阈值。  
数字 `32` 表示开的线程数，这是你应该根据自己实际情况修改的地方。  

接下来每一项表示是否进行枚举二人组，分别为辅刺枚举、**传统**无刺枚举、虚评枚举。  
第一个数 `0/1` 表示是否进行这样的枚举，第二个数为阈值。阈值可以适当降低，但不要降低太多。  

当你打算把已经配过二人组的号库导入这个工具时，请把号库文件放进 `input` 文件夹中，然后把上面三表示是否枚举二人组的 `0/1` 设为 0，随后运行 `all.exe`。然后再将这三个 `0/1` 改为 1, 放入为经过二人组配队的新号堆，重新运行。

-----------------

将你的输入文件放入 `input` 文件夹，请确保是 utf-8 格式。双击 `all.exe`，开始配队。我会自动和已有的号去重，并且经过筛子，再进行配队。  

完成后输出会在 `out` 文件夹，注意配队的输出是追加而非覆盖。分为 `WC.txt`、`FC.txt`、`XP.txt`。输出格式为每一行 `<score> <name1>+<name2>`。

该工具在配队的同时还帮你整理了号库。你可以，或者说应该把每天测的号都放进 `input` 中运行一下。这个工具会把已经输入过的号存到 `file` 文件夹中，配队的时候只会枚举含新号的二人组。

`file` 文件夹存全部号，`new` 文件夹存你最近几次（定义为，你上一次清空到现在）的新号，并进行了整理（测了几种 sp 并排序）。  

等到你什么时候有闲情雅致了，可以把 `new` 或者 `out` 里面的号/二人组给开箱了，然后可以将其清空。这就是为什么我采用追加输出而非覆盖输出。


`get.exe` 可以更方便地帮你把号把二人组在 out 文件夹中提取出来，最终结果会按照超出阈值多少进行排序，有重复的会去重。


-----------------


如果你想知道里面的组件具体使用方法，几乎所有组件 exe 都需要用 cli 调用。  

具体来说，你需要在该目录下打开终端。如果是 cmd 的话输入 `xxx.exe 参数`，如果是 powershell 的话要 `./xxx.exe 参数`。直接双击打开程序是无效的。以下用法说明时默认是 cmd。

你可以双击 `start.bat` 这个文件来打开当前目录下的终端。

除了特别标注的以外，输入的任何文件地址两两之间不应该相同。特别标注的也不保证不出 bug。

每个 exe 的参数列表及说明如下，具体使用案例可以查看 `all.cpp`。

- `move.exe <source_file> <destination_file>`
使用方法：`move.exe  <source_file> <destination_file>`。  
用途：将 `source_file` 内的全部内容拷贝到 `destination_file` 的末尾。

- `divide.exe`
使用方法：`divide.exe <input_file> <output_file_1> <output_file_2>`。  
用途：将 `input_file` 里的文件按照无刺/有刺分开在 `output_file_1 和 output_file_2` 里。

- `sort.exe`
使用方法：`sort.exe <type> <input_file> <output_file>`。
用途：将 `input_file` 里的文件里的名字（名字前有某种评分）按照评分排序，输出到 `output_file` 里。`type` 为 `0/1` 表示是否将分数也输出（保留三位小数）。  
标注：`input_file` 和 `output_file` 可以相同。

- `select.exe`
使用方法：`select.exe <seive_1> <seive_2> <input_file> <output_file_1> <output_file_2>`。
用途：`input_file` 中的名字前应当有两个评分，将第一个评分大于等于阈值 `seive_1` 或者第二个评分大于等于阈值 `seive_2` 的号$\color{red}{\small{\textbf{覆盖（注：这里有更改）}}}$输出在 `output_file_1` 中，没过筛的号输出在 `output_file_2` 中。

- `duplicate.exe`  
使用方法：`duplicate.exe <input_file_1> <intput_file_2> <output_file>`。  
用途：将读取的 `input_file_1` 里的号根据自身和 `input_file_2` 中的号去重，输出到 `output_file` 中。

- `XP.exe`  
使用方法：`XP.exe <input_file> <output_file>`。  
用途：将 `input_file` 里的文件测虚评（不测虚单）输出在 `output_file` 中。  
输出格式为 `<score> <name>`。 

- `SP.exe`
使用方法：`SP.exe <type> <input_file> <output_file>`。  
用途：将 `input_file` 里的文件测预估 丝辅评/丝刺评/丝地评/丝超强单评 评分输出在 `output_file` 中。`type` 输入 `1/2/3` 分别表示丝辅评/丝刺评/丝地评/丝超强单评。  
输出格式为 `<score> <name>`。

- `XP_potential.exe`  
使用方法：`XP_potential.exe <thread_number> <input_file> <output_file>`。  
用途：将 `input_file` 里的文件测虚评和潜力虚评（将某一 `name_base` 改为 63 后所能达到的 xp 最大值）输出在 `output_file` 中。由于速度较慢，因此采用 `thread_number` 个线程并行。  
输出格式为 `<score1> <score2> <name>`。 
**注：thread_number 参数已废弃，但是为了减少工作量仍然保存，你随便输个 1 就行。**

- `SP_potential.exe`  
使用方法：`SP_potential.exe <type> <thread_number> <input_file> <output_file>`。  
用途：将 `input_file` 里的文件测丝评和潜力丝评，输入的 type 对应关系同 `SP.exe`输。出在 `output_file` 中。  
输出格式为 `<score1> <score2> <name>`。   
**注：thread_number 参数已废弃，但是为了减少工作量仍然保存，你随便输个 1 就行。**

- `two_XP.exe`  
使用方法：`two_XP.exe <type> <thread_number> <seive> <input_file_1> <input_file_2> <output_file>`。
用途：测二人组加成后的虚评和，**附加**到 `output_file` 中（不是覆盖！）。  
`type` 为 0/1 表示 `input_file_1` 内部枚举还是 `input_file_1` 与 `input_file_2` 之间两两枚举。 `thread_number` 表示开的线程数，`seive` 表示阈值。  
输出格式为 `<score> <name1+name2>`。 

- `two_WC.exe`
- 使用方法：`two_WC.exe <type> <thread_number> <seive> <input_file_1> <input_file_2> <output_file>`。  
- 用途：测二人组加成后的丝地评和，**附加**到 `output_file` 中（不是覆盖！）。  
- `type` 为 0/1 表示 `input_file_1` 内部枚举还是 `input_file_1` 与 `input_file_2` 之间两两枚举。 `thread_number` 表示开的线程数，`seive` 表示阈值。  
输出格式为 `<score> <name1+name2>`。 

- `two_FC.exe`  
使用方法：`two_FC.exe <type> <thread_number> <seive> <input_file_1> <input_file_2> <output_file>`。
用途：测二人组加成后的丝辅刺评和，**附加**到 `output_file` 中（不是覆盖！）。  
`type` 为 0/1 表示 `input_file_1` 内部枚举还是 `input_file_1` 与 `input_file_2` 之间两两枚举。 `thread_number` 表示开的线程数，`seive` 表示阈值。    
**按理来说你应该只会输入 type 为 1 的情况。并且你应该在 `input_file_1` 内放辅助，`input_file_2` 内放背刺。我在程序里只会将靠前的号测丝辅评，靠后的号测丝刺评，且内设了排除背刺嘲讽值大于辅助的情况。**
输出格式为 `<score> <name1+name2>`。 
