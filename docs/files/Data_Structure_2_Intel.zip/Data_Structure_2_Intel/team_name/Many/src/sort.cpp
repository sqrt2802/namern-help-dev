#include<bits/stdc++.h>
#include<windows.h>
using namespace std;
const int N=30000005;
struct Name{string s;double qp;};
bool cmp(Name x,Name y){return x.qp==y.qp?x.s>y.s:x.qp>y.qp;}
bool cmp2(Name x,Name y){return x.s==y.s?x.qp>y.qp:x.s>y.s;}
Name a[N];
int n,cnt;
int type;
char input_s[1024];
char output_s[1024];
int main(int argc, char* argv[]) 
{
    if (argc != 4) {
        std::cerr << "Usage: " << argv[0] << " <type> <input_file> <output_file>" << std::endl;
        return 1;
    }
    type=int(argv[1][0])-int('0');
    freopen(argv[2],"r",stdin);
    n=0;
    double x=0;
    while (cin>>x)
    {
        n++;
        a[n].qp+=x;getchar();getline(cin,a[n].s);
    }
    sort(a+1,a+n+1,cmp);
    freopen(argv[3],"w",stdout);
    for (int i=1;i<=n;i++) 
    if (a[i].s!=a[i-1].s || a[i].qp!=a[i-1].qp)  
    {
        if (type==1) printf("%.3lf ",a[i].qp);
        cout<<a[i].s<<"\n";
    }
    fflush(stdin);
    fflush(stdout);
}