#include <iostream>
#include <fstream>
#include <string>

int main(int argc, char* argv[]) {
    
    if (argc != 3) {
        std::cerr << "Usage: " << argv[0] << " <source_file> <destination_file>" << std::endl;
        return 1;
    }

    // 获取文件名参数
    std::string sourceFile = argv[1];
    std::string destinationFile = argv[2];

    // 打开源文件进行读取
    std::ifstream source(sourceFile, std::ios::binary);
    if (!source) {
        std::cerr << "Error: Unable to open source file " << sourceFile << std::endl;
        return 1;
    }

    // 打开目标文件进行追加
    std::ofstream destination(destinationFile, std::ios::binary | std::ios::app);
    if (!destination) {
        std::cerr << "Error: Unable to open destination file " << destinationFile << std::endl;
        return 1;
    }

    // 将源文件的内容复制到目标文件
    destination << source.rdbuf();

    // 关闭文件流
    source.close();
    destination.close();

    return 0;
}