#include <ctime>
#include <algorithm>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <random>
#include <windows.h>
#include <cstring>
#include <vector>
#include <pthread.h>
#pragma GCC optimize("Ofast")
#pragma GCC target("sse,sse2,sse3,ssse3,sse4,abm,mmx,avx,avx2")
#pragma GCC optimize("unroll-loops")
typedef unsigned long long u64_t;
typedef unsigned char u8_t;
using namespace std;
const char PRE='S';
int XPmin=4900,XDmin=5700,XD_XPmin=3500;
const char skillNameMap[][13] = {
	"火球术", "冰冻术", "雷击术", "地裂术", "吸血攻击", "投毒", "连击",
	"会心一击", "瘟疫", "生命之轮", "狂暴术", "魅惑", "加速术", "减速术",
	"诅咒", "治愈魔法", "苏生术", "净化", "铁壁", "蓄力", "聚气",
	"潜行", "血祭", "分身", "幻术", "防御", "守护", "伤害反弹",
	"护身符", "护盾", "反击", "吞噬", "召唤亡灵", "垂死抗争", "隐匿",
	"啧", "啧", "啧", "啧", "啧"};
string skillNameMap_2[35] = {
	"SklFire","SklIce","SklThunder","SklQuake","SklAbsorb","SklPoison","SklRapid","SklCritical","sklHalf","SklExchange","SklBerserk","SklCharm","SklHaste","SklSlow","SklCurse","SklHeal","SklRevive","SklDisperse","SklIron","SklCharge","SklAccumulate","SklAssassinate","SklSummon","SklClone","SklShadow","SklDefend","SklProtect","SklReflect","SklReraise","SklShield","SklCounter","SklMerge","SklZombie","SklUpgrade","SklHide"};
const int N = 256, M = 128, K = 64, skill_cnt = 40;
char team[N],tmq[N],fname[N], _tmp[N],suff[N],suf[N],fname2[N];
char charset[N/2];
FILE *fp;
clock_t start;
int charset_len,variable_len;
int name_len=0,suff_len;
int totcnt;
int _collect=0;
int _collect_8V_min,_collect_7V_min,_collect_HL_min,_collect_HP8V_min;
int _output_XP=1;
int _output_log=1;
int _output_speed=1;
int st[N];

char *dvt(char *p)
{
	DWORD dwNum = MultiByteToWideChar(CP_UTF8, 0, p, -1, NULL, 0);
	char *psText;
	wchar_t *pwText = (wchar_t *)malloc(dwNum * sizeof(wchar_t));
	dwNum = MultiByteToWideChar(CP_UTF8, 0, p, -1, pwText, dwNum);
	dwNum = WideCharToMultiByte(CP_ACP, 0, pwText, -1, NULL, 0, NULL, NULL);
	psText = (char *)malloc(dwNum * sizeof(char));
	dwNum = WideCharToMultiByte(CP_ACP, 0, pwText, -1, psText, dwNum, NULL, NULL);
	free(pwText);
	return psText;
}
char OOO[1024];
void puts_Chinese(string s_cn)
{
	cout<<s_cn;
	//for (int i=0;i<1023;i++) OOO[i]=s_cn[i];
	//char *PPP= dvt(OOO);
	//printf("%s",PPP);
}
struct Name
{
	u8_t ual[N],val[N],val_base[N],val_base2[N];
	u8_t name_base[M], freq[16], skill[skill_cnt], p, q,i_pre,j_pre,s_pre;
	int q_len,V,seed,PRELEN,NAMELEN;
	inline u8_t m()
	{
		q += val[++p];
		swap(val[p], val[q]);
		return val[val[p] + val[q] & 255];
	}
	inline int gen()
	{
		int u = m();
		return (u << 8 | m()) % skill_cnt;
	}
	void load_team(char *_team)
	{
		int t_len = strlen(_team)+1;
		u8_t s;
		for (int i = 0; i < N; i++) val_base[i] = i;
		for (int i = s = 0; i < N; ++i)
		{
			if (i % t_len)
				s += _team[i % t_len - 1];
			s += val_base[i];
			swap(val_base[i], val_base[s]);
		}
	}
	void load_prefix(const char *name)
	{
		memcpy(val_base2,val_base,sizeof val_base2);
		NAMELEN=name_len;
		int i,j;u8_t s;
		for (i=s=0,j=NAMELEN;i<PRELEN;i++,j++)
		{
			s += name[j] + val_base2[i];
			swap(val_base2[i], val_base2[s]);
			if (j==NAMELEN) j=-1;
		}
		i_pre=i;j_pre=j;s_pre=s;
		if (i_pre==0) j_pre=name_len,s_pre=0;
	}
	void load_name(const char *name)
	{
		q_len = -1;
		u8_t s=s_pre;
		memcpy(val, val_base2, sizeof val);
		for (int i=i_pre,j=j_pre; i < N; i++,j++)
		{
			s += name[j] + val[i];
			swap(val[i], val[s]);
			if (j==NAMELEN) j=-1;
		}
		for (int i = s = 0, j = NAMELEN; i < N; i++,j++)
		{
			s += name[j] + val[i];
			swap(val[i], val[s]);
			if (j==NAMELEN) j=-1;
		}
		for (int i = 0; i < 96; i += 8) {
			ual[i + 0] = val[i + 0] * 181 + 160;
			ual[i + 1] = val[i + 1] * 181 + 160;
			ual[i + 2] = val[i + 2] * 181 + 160;
			ual[i + 3] = val[i + 3] * 181 + 160;
			ual[i + 4] = val[i + 4] * 181 + 160;
			ual[i + 5] = val[i + 5] * 181 + 160;
			ual[i + 6] = val[i + 6] * 181 + 160;
			ual[i + 7] = val[i + 7] * 181 + 160;
		}
		for (int i = 0; i < 96 && q_len < 30; i ++)
			if (ual[i] >= 89 && ual[i] < 217)
				name_base[++q_len] = ual[i] & 63;
		if (q_len < 30) {
			for (int i = 96; i < N; i += 8) {
				ual[i + 0] = val[i + 0] * 181 + 160;
				ual[i + 1] = val[i + 1] * 181 + 160;
				ual[i + 2] = val[i + 2] * 181 + 160;
				ual[i + 3] = val[i + 3] * 181 + 160;
				ual[i + 4] = val[i + 4] * 181 + 160;
				ual[i + 5] = val[i + 5] * 181 + 160;
				ual[i + 6] = val[i + 6] * 181 + 160;
				ual[i + 7] = val[i + 7] * 181 + 160;
			}
			for (int i = 96; i < N && q_len < 30; i ++)
				if (ual[i] >= 89 && ual[i] < 217)
					name_base[++q_len] = ual[i] & 63;
		}
		V = 0;
#define median(x, y, z) x<y?(x<z?(y<z?y:z):x):(y<z?(x<z?x:z):y)
		V += median(name_base[28], name_base[29], name_base[30]);
		if (V < 24) return;
		V += median(name_base[13], name_base[14], name_base[15]);
		V += median(name_base[16], name_base[17], name_base[18]);
		V += median(name_base[25], name_base[26], name_base[27]);
		if (V < 165) return;
		V += median(name_base[10], name_base[11], name_base[12]);
		V += median(name_base[19], name_base[20], name_base[21]);
		V += median(name_base[22], name_base[23], name_base[24]);
		if (V < 250) return;
		sort(name_base, name_base + 10);
		V += (154 + name_base[3] + name_base[4] + name_base[5] + name_base[6]) / 3;
		if (V < 380) return;
	}
	void loading_name(const char *name)
	{
		memcpy(val, val_base, sizeof val);
		q_len = -1;
		u8_t s;
		int t_len=strlen(name)+1;
		for (int _ = 0; _ < 2; _++)
			for (int i = s = 0; i < N; i++)
			{
				if (i % t_len) s += name[i % t_len - 1];
				s += val[i];
				swap(val[i], val[s]);
			}
		for (int i = 0; i < 96; i += 8) {
			ual[i + 0] = val[i + 0] * 181 + 160;
			ual[i + 1] = val[i + 1] * 181 + 160;
			ual[i + 2] = val[i + 2] * 181 + 160;
			ual[i + 3] = val[i + 3] * 181 + 160;
			ual[i + 4] = val[i + 4] * 181 + 160;
			ual[i + 5] = val[i + 5] * 181 + 160;
			ual[i + 6] = val[i + 6] * 181 + 160;
			ual[i + 7] = val[i + 7] * 181 + 160;
		}
		for (int i = 0; i < 96 && q_len < 30; i ++)
			if (ual[i] >= 89 && ual[i] < 217)
				name_base[++q_len] = ual[i] & 63;
		if (q_len < 30) {
			for (int i = 96; i < N; i += 8) {
				ual[i + 0] = val[i + 0] * 181 + 160;
				ual[i + 1] = val[i + 1] * 181 + 160;
				ual[i + 2] = val[i + 2] * 181 + 160;
				ual[i + 3] = val[i + 3] * 181 + 160;
				ual[i + 4] = val[i + 4] * 181 + 160;
				ual[i + 5] = val[i + 5] * 181 + 160;
				ual[i + 6] = val[i + 6] * 181 + 160;
				ual[i + 7] = val[i + 7] * 181 + 160;
			}
			for (int i = 96; i < N && q_len < 30; i ++)
				if (ual[i] >= 89 && ual[i] < 217)
					name_base[++q_len] = ual[i] & 63;
		}
		V = 0;
		V += median(name_base[10], name_base[11], name_base[12]);
		V += median(name_base[13], name_base[14], name_base[15]);
		V += median(name_base[16], name_base[17], name_base[18]);
		V += median(name_base[19], name_base[20], name_base[21]);
		V += median(name_base[22], name_base[23], name_base[24]);
		V += median(name_base[25], name_base[26], name_base[27]);
		V += median(name_base[28], name_base[29], name_base[30]);
		sort(name_base, name_base + 10);
		V += (154 + name_base[3] + name_base[4] + name_base[5] + name_base[6])/ 3;
	}
	void calc_skills(const char *name)
	{
		q_len = -1;
		for (int i = 0; i < N; i += 8) {
			ual[i + 0] = val[i + 0] * 181 + 160;
			ual[i + 1] = val[i + 1] * 181 + 160;
			ual[i + 2] = val[i + 2] * 181 + 160;
			ual[i + 3] = val[i + 3] * 181 + 160;
			ual[i + 4] = val[i + 4] * 181 + 160;
			ual[i + 5] = val[i + 5] * 181 + 160;
			ual[i + 6] = val[i + 6] * 181 + 160;
			ual[i + 7] = val[i + 7] * 181 + 160;
		}
		for (int i = 0; i < N; i ++)
			if (ual[i] >= 89 && ual[i] < 217)
				name_base[++q_len] = ual[i] & 63;
		u8_t *a = name_base + K;
		for (int i = 0; i < skill_cnt; i ++) skill[i] = i;
		memset(freq, 0, sizeof freq);
		p = q = 0;
		for (int s = 0, _ = 0; _ < 2; _ ++)
			for (int i = 0; i < skill_cnt; i ++) {
				s = (s + gen() + skill[i]) % skill_cnt;
				swap(skill[i], skill[s]);
			}
		int last = -1;
		for (int i = 0, j = 0; i < K; i += 4, j ++) {
			u8_t p = min({a[i], a[i + 1], a[i + 2], a[i + 3]});
			if (p > 10 && skill[j] < 35) {
				freq[j] = p - 10;
				if (skill[j] < 25) last = j;
			}
			else freq[j] = 0;
		}
		if (last != -1) freq[last] <<= 1;
		if (freq[14] && last != 14)
			freq[14] += min({name_base[60], name_base[61], freq[14]});
		if (freq[15] && last != 15)
			freq[15] += min({name_base[62], name_base[63], freq[15]});
	}
};
int n, jyztxdy, prelen, tp;
long long l, r;
u8_t idx[16];
Name name_initial;
bool flag_out=0;
void read(char *p)
{
    int tot=0;
	while ((*p = getchar()) == '\n') 
    {tot++;if (tot==1000) {flag_out=1;return;}}
    tot=0;
	while ((*++p = getchar()) != '\n')
    {tot++;if (tot==1000) {flag_out=1;return;}}
	*p = 0;
}
void hanxu_Poly(double *xp,double *x) {
	int l,i,p,q,j;
	double r;
    for (int y = 0; y < 1034; y++) {
        l = 44;
        i = 0, p = 0, q = 0;
		r = 0;
        j = y;
        for (int k = 0; k < 45; k++) {
            i++, p += (i>2), q = j, j = j - l + p;
            if (j < 0) break;
        }
        if (i == 1) r = x[q];
        if (i > 1) r = x[p] * x[p + q];
        xp[y] = r;
    }
}
double xp_array[1034],xp_x[44],score,scoreQD;
char NAME_SHADOW[N];
int prop[8];
char NAME_ALL[N],TEAM[N],NAME[N],NAME_ALL2[N];
void cvt_name()
{
	int len = MultiByteToWideChar(CP_ACP, 0, NAME_ALL2, -1, NULL, 0);
	wchar_t *wstr = new wchar_t[len + 1];
	memset(wstr, 0, len + 1);
	MultiByteToWideChar(CP_ACP, 0, NAME_ALL2, -1, wstr, len);
	len = WideCharToMultiByte(CP_UTF8, 0, wstr, -1, NULL, 0, NULL, NULL);
	memset(NAME_ALL, 0, len + 1);
	WideCharToMultiByte(CP_UTF8, 0, wstr, -1, NAME_ALL, len, NULL, NULL);
	if (wstr) delete[] wstr;
}

Name name;
int tot_cnt=0;
struct Skill{int freq,id;};
vector<Skill> vec;
bool cmp(Skill a,Skill b){return a.freq==b.freq?a.id<b.id:a.freq>b.freq;}
int main(int argc, char* argv[]) 
{
    cerr<<"Count Number\n";
    freopen(argv[3],"r",stdin);
    while (1)
    {
        if (tot_cnt%1000==0) cerr<<"cnt="<<tot_cnt<<"\n";
        char *read_p = NAME_ALL;
        int tot = 0;
        bool flag_out = 0;
        while ((*read_p = getchar()) == '\n') {
            tot++;
            if (tot == 1000) {
                flag_out = 1;
                break;
            }
        }
        tot = 0;
        while ((*++read_p = getchar()) != '\n') {
            tot++;
            if (tot == 1000) {
                flag_out = 1;
                break;
            }
        }
        tot_cnt++;
        if (flag_out==1) break;
        *read_p = 0;
    }
    fflush(stdin);
    fclose(stdin);
    freopen("./openbox/input.txt","w",stdout);
    cout<<tot_cnt-1<<"\n";
    tot_cnt=0;
    freopen(argv[3],"r",stdin);
    while (1)
    {
        tot_cnt++;
        if (tot_cnt%1000==0) cerr<<"cnt="<<tot_cnt<<"\n";
        for (int i=0;i<N;i++) NAME_ALL[i]=NAME_ALL2[i]=0;
        memset(NAME_ALL,0,sizeof(NAME_ALL));
        memset(NAME,0,sizeof(NAME));
        memset(TEAM,0,sizeof(TEAM));
        memset(NAME_SHADOW,0,sizeof(NAME_SHADOW));
        read(NAME_ALL);//cvt_name();
		
		if (flag_out==1) break;
        int p=-1;
        for (int i=0;i<N;i++) if (NAME_ALL[i]=='@') p=i;
        for (int i=p+1;i<N;i++) TEAM[i-p-1]=NAME_ALL[i];
        if (p!=-1) for (int i=0;i<p;i++) NAME[i]=NAME_ALL[i];
        else for (int i=0;i<N;i++) NAME[i]=NAME_ALL[i];
        name.load_team(TEAM);name.loading_name(NAME);
        //for (int i=0;i<24;i++) cout<<(int)NAME_ALL2[i]<<" ";cout<<"\n";
        //for (int i=0;i<24;i++) cout<<(int)NAME_ALL[i]<<" ";cout<<"\n";
        prop[0] = median(name.name_base[10], name.name_base[11], name.name_base[12]);
		prop[1] = median(name.name_base[13], name.name_base[14], name.name_base[15]);
		prop[2] = median(name.name_base[16], name.name_base[17], name.name_base[18]);
		prop[3] = median(name.name_base[19], name.name_base[20], name.name_base[21]);
		prop[4] = median(name.name_base[22], name.name_base[23], name.name_base[24]);
		prop[5] = median(name.name_base[25], name.name_base[26], name.name_base[27]);
		prop[6] = median(name.name_base[28], name.name_base[29], name.name_base[30]);
		prop[7] = 154 +  name.name_base[3] + name.name_base[4] + name.name_base[5] + name.name_base[6];
        for (int j = 0; j < 7; j++) prop[j] += 36; xp_x[0] = prop[7];
        name.calc_skills(NAME);
		//Ahri+diy[50,51,90,130,150,70,89,210]{"SklCharm":46,"SklHaste":64,"SklHeal":128,"UselessSlot":-2147483647}
		printf("%s+diy[",NAME_ALL);
        printf("%d,",prop[0]);
        printf("%d,",prop[1]);
        printf("%d,",prop[2]);
        printf("%d,",prop[3]);
        printf("%d,",prop[4]);
        printf("%d,",prop[5]);
        printf("%d,",prop[6]);
        printf("%d]",prop[7]);
		printf("{");
		vec.clear();
		for (int i=0;i<16;i++) if (name.freq[i]>0) vec.push_back({name.freq[i],name.skill[i]});
		//sort(vec.begin(),vec.end(),cmp);
		for (int i=0;i<vec.size();i++) if (i!=vec.size()-1)  {cout<<"\""<<skillNameMap_2[vec[i].id]<<"\":";printf(" %d,",vec[i].freq);}
		else {cout<<"\""<<skillNameMap_2[vec[i].id]<<"\":";printf(" %d}",vec[i].freq);}
		printf("\n");
    }
	fflush(stdout);
	fclose(stdout);
	freopen("./openbox/run.bat","w",stdout);
	cout<<"pair.exe "<< argv[1] <<" "<<argv[2]<<" input.txt\n";
	fflush(stdout);
	fclose(stdout);
	cerr<<"2333\n";
	system("cd openbox & run.bat");
	cerr<<"copying\n";
	freopen("./openbox/output.txt","r",stdin);
	freopen(argv[4],"w",stdout);
	string tmptmp;
	while (getline(cin,tmptmp))
	{
		cout<<tmptmp<<"\n";
	}
	fflush(stdout);
	fflush(stdin);
	fclose(stdout);
	fclose(stdin);
}
