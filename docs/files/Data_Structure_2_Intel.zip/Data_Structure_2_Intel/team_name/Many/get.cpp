#include<bits/stdc++.h>
using namespace std;
map<string, int> Map;
int score;
string name;
int tmp;
int s1,s2,s3;
int type;
set< pair<int, string> > S;
int main()
{
    // 使用 ifstream 处理文件输入
    cin>>type;
    ifstream configFile("config.txt");
    configFile>>tmp;configFile>>tmp;configFile>>tmp;configFile>>tmp;configFile>>tmp;
    configFile>>tmp;configFile>>s1;
    configFile>>tmp;configFile>>s2;
    ifstream fcFile("./out/FS.txt");
    while (fcFile >> score) {
        fcFile.get(); // 吃掉换行符
        getline(fcFile, name);
        Map[name] = max(Map[name], score - s1);
    }
    fcFile.close();  // 关闭 FC.txt 文件流
    
    // 继续使用 ifstream 处理 WC.txt
    ifstream wcFile("./out/HS.txt");
    while (wcFile >> score) {
        wcFile.get(); // 吃掉换行符
        getline(wcFile, name);
        Map[name] = max(Map[name], score - s2);
    }
    wcFile.close();  // 关闭 WC.txt 文件流
    

    for (auto x : Map) {
        S.insert(make_pair(-x.second,x.first));
    }
    // 输出结果到 out.txt
    ofstream outFile("./out/out.txt");
    for (auto x : S) {
        if (type == 1) outFile << -x.first << " " << x.second << "\n";
        if (type == 0) outFile << x.second << "\n";
    }
    outFile.close();  // 关闭输出文件流
    
    return 0;
}
