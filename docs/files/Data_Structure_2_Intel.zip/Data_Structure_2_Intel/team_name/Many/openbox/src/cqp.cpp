#include <ctime>
#include <algorithm>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <random>
#include <windows.h>
#include <cstring>
#include <vector>
#include <pthread.h>
#pragma GCC optimize("Ofast")
#pragma GCC target("sse,sse2,sse3,ssse3,sse4,abm,mmx,avx,avx2")
#pragma GCC optimize("unroll-loops")
#pragma runtime_checks
typedef unsigned int u64_t;
typedef unsigned char u8_t;
using namespace std;
const char PRE='S';
double outputmin_screen;
double outputmin;
int acc;
int silent;
string type;
char input_filename_init[1005];
const char skillNameMap[][13] = {
	"火球术", "冰冻术", "雷击术", "地裂术", "吸血攻击", "投毒", "连击",
	"会心一击", "瘟疫", "生命之轮", "狂暴术", "魅惑", "加速术", "减速术",
	"诅咒", "治愈魔法", "苏生术", "净化", "铁壁", "蓄力", "聚气",
	"潜行", "血祭", "分身", "幻术", "防御", "守护", "伤害反弹",
	"护身符", "护盾", "反击", "吞噬", "召唤亡灵", "垂死抗争", "隐匿",
	"啧", "啧", "啧", "啧", "啧"};
const int N = 256, M = 128, K = 64, skill_cnt = 40;
char team[N],tmq[N],fname[N], _tmp[N],suff[N],suf[N],fname2[N];

string folder_name;
int ALL_totnum;
int all_task_num;

FILE *fp_input;
FILE *fp;
clock_t start;
bool DEBUG_MOD_ON=0;
int totcnt;
int _output_XP=1;
int _output_UTF=0;
int _output_log=1;
int _output_speed=1;
int cur_thread_number=100;
int cur_speed_tasks;
FILE *fp3;
FILE *fp4;
pthread_mutex_t Mutex_Lock=PTHREAD_MUTEX_INITIALIZER;
char *cvt(const char *gb2312)
{
	int len = MultiByteToWideChar(CP_ACP, 0, gb2312, -1, NULL, 0);
	wchar_t *wstr = new wchar_t[len + 1];
	memset(wstr, 0, len + 1);
	MultiByteToWideChar(CP_ACP, 0, gb2312, -1, wstr, len);
	len = WideCharToMultiByte(CP_UTF8, 0, wstr, -1, NULL, 0, NULL, NULL);
	char *str = new char[len + 1];
	memset(str, 0, len + 1);
	WideCharToMultiByte(CP_UTF8, 0, wstr, -1, str, len, NULL, NULL);
	if (wstr)
		delete[] wstr;
	return str;
}
char charset_output[1000005];
char *dvt(char *p)
{
	DWORD dwNum = MultiByteToWideChar(CP_UTF8, 0, p, -1, NULL, 0);
	char *psText;
	wchar_t *pwText = (wchar_t *)malloc(dwNum * sizeof(wchar_t));
	dwNum = MultiByteToWideChar(CP_UTF8, 0, p, -1, pwText, dwNum);
	dwNum = WideCharToMultiByte(CP_ACP, 0, pwText, -1, NULL, 0, NULL, NULL);
	psText = (char *)malloc(dwNum * sizeof(char));
	dwNum = WideCharToMultiByte(CP_ACP, 0, pwText, -1, psText, dwNum, NULL, NULL);
	free(pwText);
	return psText;
}
char OOO[1024];
void puts_Chinese(string s_cn)
{
	for (int i=0;i<s_cn.size();i++) OOO[i]=s_cn[i];
    for (int i=s_cn.size();i<1024;i++) OOO[i]=0;
	char *PPP= dvt(OOO);
	fprintf(stderr,"%s\n",PPP);
}
void read(char *p)
{
	while ((*p = getchar()) == '\n');
	while ((*++p = getchar()) != '\n');
	*p = 0;
}
void hanxu_Poly(double *xp,double *x) {
	int l,i,p,q,j;
	double r;
    for (int y = 0; y < 1034; y++) {
        l = 44;
        i = 0, p = 0, q = 0;
		r = 0;
        j = y;
        for (int k = 0; k < 45; k++) {
            i++, p += (i>2), q = j, j = j - l + p;
            if (j < 0) break;
        }
        if (i == 1) r = x[q];
        if (i > 1) r = x[p] * x[p + q];
        xp[y] = r;
    }
}
int max_sum,outputmax,max_XD; 

void getfilename()
{
	time_t time_now=time(NULL);
	int unix_time=time_now;
	string time_tmp="";
	while (unix_time)
	{
		time_tmp=char(unix_time%10+'0')+time_tmp;
		unix_time/=10;
	}
	for (int i=0;i<time_tmp.size();i++) fname[i+4]=time_tmp[i];
	fname[time_tmp.size()+4]='.';
	fname[time_tmp.size()+5]='t';
	fname[time_tmp.size()+6]='x';
	fname[time_tmp.size()+7]='t';
	fname[time_tmp.size()+8]=0;
	fname[0]='o';fname[1]='u';fname[2]='t';fname[3]='-';
}
pthread_mutex_t mutex_lock;
pthread_cond_t ADD,GET;


typedef struct{
    int task_id;
    int filename_id;
    int tot,outputmax;
}TaskData;
#define MAX_QUEUE_LEN 4
struct TaskQueue{
    // Circular Queue
    TaskData data[MAX_QUEUE_LEN];
    // head, tail of this queue
    int h, t; 
    // closed means no more data can be added
    int closed;
}QData;

void queue_init(){
    // init/reset the queue
    pthread_cond_init(&ADD,NULL);
    pthread_cond_init(&GET,NULL);
    QData.h = 0;
    QData.t = 0;
    QData.closed = 0;
}

int queue_get(TaskData *ret){
    pthread_mutex_lock(&mutex_lock);
    while (QData.h>=QData.t)
    {
        //empty, avoid busy waiting
        if (QData.closed==1) {pthread_mutex_unlock(&mutex_lock);return -1;}
        pthread_cond_wait(&GET,&mutex_lock);
    }
    int h = QData.h;
    QData.h++;
    *ret = QData.data[h%MAX_QUEUE_LEN]; // circular use the QData.data
    pthread_cond_signal(&ADD);
    pthread_mutex_unlock(&mutex_lock);
    return 0; // 0 means success
}

int queue_add(TaskData data){
    pthread_mutex_lock(&mutex_lock);
    //printf("MAX LEN = %d\n", (MAX_QUEUE_LEN));
    while (QData.t-QData.h>=MAX_QUEUE_LEN) 
    {
        if(QData.closed)  {pthread_mutex_unlock(&mutex_lock);return -1;}
        //Full, waiting
        pthread_cond_wait(&ADD,&mutex_lock);
    }
    if(QData.closed)  {pthread_mutex_unlock(&mutex_lock);return -1;}
    int t = QData.t;
    QData.t++;
    QData.data[t%MAX_QUEUE_LEN] = data;
    pthread_cond_signal(&GET);
    pthread_mutex_unlock(&mutex_lock);
    return 0; // 0 means success
}

void queue_close()
{
    pthread_mutex_lock(&mutex_lock);
    QData.closed = 1;
    pthread_cond_broadcast(&GET);
    pthread_cond_broadcast(&ADD);
    pthread_mutex_unlock(&mutex_lock);
}

int NUMBER_PER_TASK=100;
int NUMBER_OF_WORKER_THREAD=10;

mt19937_64 Rnd(time(0));
int task_busy[100005];
int get_task_free()
{
    for (int i=0;i<1005;i++) if (task_busy[i]==0)  return i;
}

void *producer(void* arg)
{
    int task_cnt=-1;
	char tmp[N*20],tmr[N*20];
	FILE *fp_cur;
    for (int i=1;i<=ALL_totnum;i+=NUMBER_PER_TASK)
    {
	    pthread_mutex_lock(&Mutex_Lock);
        int j=get_task_free();
		string inputname_tmp="./"+folder_name+"/input"+to_string(j);
        for (int k=0;k<inputname_tmp.size();k++) tmp[k]=inputname_tmp[k];tmp[inputname_tmp.size()]=0;
        fp_cur=fopen(tmp,"w");
        task_busy[j]=1;
		
		//fprintf(fp,"get task step 2.3,k =[%d,%d] %d\n",i,i,task_cnt+1);
		
        for (int k=i;k<=min(NUMBER_PER_TASK+i-1,ALL_totnum);k++)
        {
            fscanf(fp_input, "%[^\n]", tmr);
            fgetc(fp_input);
            fprintf(fp_cur,"%s\n",tmr);
            //fprintf(stderr,"%d %s %s\n",k,tmp,tmr);
            //Sleep(30);
        }
        //Sleep(2000);
        fflush(fp_cur);
		fclose(fp_cur);
		string outputname_tmp="./"+folder_name+"/output"+to_string(j);
		fp_cur=fopen(outputname_tmp.c_str(),"w");
		fflush(fp_cur);
		fclose(fp_cur);
        task_cnt++;
        TaskData data;
        data.task_id=task_cnt;
        data.tot=0;
        data.filename_id=j;
		if (i+NUMBER_PER_TASK-1>=ALL_totnum) all_task_num=task_cnt;
	    pthread_mutex_unlock(&Mutex_Lock);
        if (queue_add(data)==-1) fprintf(stderr,"task%d failed to create!\n!\n!\n!\n!\n",task_cnt);
    }
    queue_close();
    return ((void*)0);
}
pthread_t ptid,ctid[40],rtid;

int mex_cur;
bool mex_vis[100000000];
int task_finished_number;
clock_t la=start;
int consumer_id=0;
void *reader(void* arg)
{
	while (1)
	{
		cin>>cur_thread_number;
		fprintf(stderr,"thread_number is %d now.\n",cur_thread_number);
	}
}

void *consumer(void* arg)
{
	int task_finished_in_c=0;
    TaskData data;
	bool output_log=_output_log;
	bool output_speed=_output_speed;
	bool output_XP=_output_XP;
    bool output_UTF=_output_UTF;

	int cur_consumer_id;
	string _cmd="";
    char cmd[1005];
	pthread_mutex_lock(&Mutex_Lock);
	consumer_id++;
	cur_consumer_id=consumer_id;
	pthread_mutex_unlock(&Mutex_Lock);
    while (queue_get(&data)==0)
    {
        pthread_mutex_lock(&Mutex_Lock);
        int j=data.filename_id;
        string inputname_tmp="./"+folder_name+"/input"+to_string(j);
        string outputname_tmp="./"+folder_name+"/output"+to_string(j);
        char outputname_tmp2[1005];
        for (int k=0;k<outputname_tmp.size();k++) outputname_tmp2[k]=outputname_tmp[k];
        outputname_tmp2[outputname_tmp.size()]=0;
        
        pthread_mutex_unlock(&Mutex_Lock);
        _cmd="cmd /c node.exe --no-warnings cqp.js "+type+" "+to_string(acc)+" "+to_string(outputmin)+" "+inputname_tmp+" "+outputname_tmp+" "+to_string(outputmin_screen);
        if (!silent) _cmd+=" -s";
        for (int k=0;k<_cmd.size();k++) cmd[k]=_cmd[k];cmd[_cmd.size()]=0;
		//fprintf(stderr,"%d %s\n",data.task_id,cmd);

		//system("taskkill /IM node.exe /F");
		
		//fprintf(stderr,"%d done\n",data.task_id);
        system(cmd);
		//fprintf(stderr,"%s\n",cmd);
		
        pthread_mutex_lock(&Mutex_Lock);
		
		task_finished_number++;
        
        task_busy[j]=0;
		
        
		mex_vis[data.task_id]=1;while (mex_vis[mex_cur]) mex_cur++;
        if (task_finished_number%10==0) 
		{
			if (output_log) fprintf(stderr,"task%d finished,task_mex=%d,count:%d\n",data.task_id,mex_cur,task_finished_number*NUMBER_PER_TASK);
			else fprintf(fp3,"task%d finished,task_mex=%d,count:%d\n",data.task_id,mex_cur,task_finished_number*NUMBER_PER_TASK);
		}
		clock_t end=clock();double tm = 1.0 * (end - start) / CLOCKS_PER_SEC;
		int tmlft= ((ALL_totnum-1ll*task_finished_number*NUMBER_PER_TASK)*1.0/(1ll*task_finished_number*NUMBER_PER_TASK))*tm;
		if (task_finished_number%10==0)
		{
			if (output_speed) fprintf(stderr, "time: %.2fs, speed: %.0lf/d,time left:%dh%dm%ds\n", tm, 1.0*task_finished_number  / tm * 86400*NUMBER_PER_TASK,tmlft/3600,(tmlft%3600)/60,tmlft%60);
			else fprintf(fp4, "time: %.2fs, speed: %.0lf/d,time left:%dh%dm%ds\n", tm, 1.0*task_finished_number/tm * 86400*NUMBER_PER_TASK,tmlft/3600,(tmlft%3600)/60,tmlft%60);
		}
		
		if (task_finished_number%(cur_speed_tasks)==0)
		{
			double tm2= 1.0 * (end-la)/CLOCKS_PER_SEC;
			int tmlft2= ((ALL_totnum-1ll*task_finished_number*NUMBER_PER_TASK)*1.0/(cur_speed_tasks*NUMBER_PER_TASK))*tm2;
			fprintf(stderr,"cur_speed:%d/d,time left(?):%dh%dm%ds\n\n",int(86400*NUMBER_PER_TASK*cur_speed_tasks*1.0/tm2),tmlft2/3600,(tmlft2%3600)/60,tmlft2%60);
			la=end;
		}
		//fprintf(stderr,"%d done\n",task_finished_number);
		if (all_task_num!=0 && mex_cur==all_task_num+1)
		{
			fprintf(stderr,"\n\n\nAll done.\n\n\n\n");
		}
        pthread_mutex_unlock(&Mutex_Lock);
		
		while (cur_consumer_id>cur_thread_number) Sleep(2000);
    }
    return ((void*)0);
}
void get_fname_2()
{
	read(fname);
	fprintf(stderr,"fname=%s\n",fname);
	for (int i=100;i>=6;i--) fname[i]=fname[i-6];
	fname[0]='.';fname[1]='/';fname[2]='o';fname[3]='u';fname[4]='t';fname[5]='/';
}
void get_fname_1()
{
	read(fname);
	if (fname[0]=='+'&&fname[1]=='\0')
	{
		fname[0]='o',fname[1]='u',fname[2]='t',fname[3]='-';
		for (int i=4;i<=10;i++) fname[i]=Rnd()%10+'0';
		fname[11]='.',fname[12]='t',fname[13]='x',fname[14]='t';
		fname[15]='\0';
	} else 	if (fname[0]=='-'&&fname[1]=='\0') getfilename();
	fprintf(stderr,"fname=%s\n",fname);
	for (int i=100;i>=6;i--) fname[i]=fname[i-6];
	fname[0]='.';fname[1]='/';fname[2]='o';fname[3]='u';fname[4]='t';fname[5]='/';
}

void choose_settings()
{
	puts_Chinese("在开始前，是否需要清空 out 文件夹(0/1)");int clear;
	puts_Chinese("注：我会采用删除整个文件夹再创建这个文件夹的方式");
	cin>>clear;
	if (clear==1)
	{
		const char* command1 = "rd /s /q out"; // 使用 Windows 命令清空目录
		int result = system(command1);
		if (result == 0) cerr << "Successfully removed directory.\n";
		else cerr << "Error removing directory!\n";
		 
		const char* command2 = "mkdir out"; // 使用 Windows 命令清空目录
		result = system(command2);
		if (result == 0 ) cerr<<"Successfuly create directory.\n";
		else cerr<<"Error removing directory!\n";
	}
	puts_Chinese("输入类型(1/2)：");cin>>type;
	puts_Chinese("输入准确度：");cin>>acc;
	puts_Chinese("输入输出在文件中的阈值：");cin>>outputmin;
	puts_Chinese("输入输出在屏幕上的阈值：");cin>>outputmin_screen;
    puts_Chinese("输入总号量：");cin>>ALL_totnum;
    puts_Chinese("输入输入文件名：");read(input_filename_init);fp_input=fopen(input_filename_init,"r");
	puts_Chinese("是否将 task 完成情况的日志输出在文件中(0 表示输出在文件里，1 表示输出在屏幕上");cin>>_output_log;
	if (_output_log==0)
	{
		puts_Chinese("输入文件名");
		get_fname_2();fp3=fopen(fname,"a");if (!fp3){fputs("Can't open the file'", stderr);system("pause");}
	}
	puts_Chinese("是否将速度显示输出在文件中(0 表示输出在文件里，1 表示输出在屏幕上");
	cin>>_output_speed;
	if (_output_speed==0)
	{
		puts_Chinese("输入文件名");
		get_fname_2();fp4=fopen(fname,"a");if (!fp4){fputs("Can't open the file'", stderr);system("pause");}
	}
	queue_init();start = clock();
	puts_Chinese("输入你要开的线程数：");cin>>NUMBER_OF_WORKER_THREAD;cur_thread_number=NUMBER_OF_WORKER_THREAD;
    fprintf(stderr,"NUMBER_OF_WORKER_THREAD is %d\n",NUMBER_OF_WORKER_THREAD);
	puts_Chinese("每个 task 的测号量：");cin>>NUMBER_PER_TASK;
	puts_Chinese("每测多少个 task 计算一次 cur_speed");cin>>cur_speed_tasks;
    puts_Chinese("是否将每一组的胜率显示在屏幕上(0/1)（强烈建议在多线程的时候不要使用！）");cin>>silent;

	
    
}
int main()
{
	choose_settings();
    pthread_create(&ptid,NULL,producer,NULL);
    for (int i=0;i<NUMBER_OF_WORKER_THREAD;i++) pthread_create(&ctid[i],NULL,consumer,NULL);
	pthread_create(&rtid,NULL,reader,NULL);
    pthread_join(ptid,NULL);
    for (int i=0;i<NUMBER_OF_WORKER_THREAD;i++) pthread_join(ctid[i],NULL);
    pthread_join(rtid,NULL);
	fputs("Done.Click enter to close.", stderr);
    
	system("pause");	
}
