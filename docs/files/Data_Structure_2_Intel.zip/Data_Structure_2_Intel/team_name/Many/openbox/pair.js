"use strict";
const process = require("process");
const fs = require("fs");
const path = require("path");
const readline = require("readline");
const md5_module = require("./md5.js");

const args = process.argv.slice(2);
const file_path = args[3];
const team_type = Number(args[0]);
const output_file_path = args[4];
const acc = Number(args[1]);
const sieve = Number(args[2]);
const sieve_screen = Number(args[5]);

const file_content = fs.readFileSync(file_path, "utf-8");
const lines = file_content.split("\n");

const results = [];
var verbose = true;
if (args.includes("--silent") || args.includes("-s")) {
    verbose = false;
}

if (!fs.existsSync(file_path)) {
    console.log("工具错误，请与开发者联系。错误信息: 输入文件不存在");
    process.exit(0);
}

async function main() {
    var target;
    target = [
        '巨整蜻祠陆@Shabby_fish++luogu.com.cn/paste/q9h8sdzk@Shabby_fish',
        '乙烷 9h2ieAwJ/]Wxk7R@TigerStar++癌细胞 Qgu35DIL[Q8us/3@TigerStar',
        '<αλ>-8ed1q4wi@ReturnVoid++<ακ>-5jmt0g6o@ReturnVoid',
        '双向})DETWQK@LuoTianyi++ilem ?MJxj&<^@LuoTianyi',
        '游云PHGSQZLRJ@涵虚++月涌DKYYCMKAV@涵虚',
        'Regulus VynkvDehqnzlqQX@Squall++十六夜咲夜#EF4V65LZD4OGGZG@Squall',
        '光YLqKf5rv9EU9lnc@Squall++魂魄妖梦 AKG1OENX@Squall',
        'C(/y&)@暗黑突击++GSSPOMRH@暗黑突击',
        'XxVt-b5zMsWf6wk@新纪元++I3TvXgfqq1giN92@新纪元',
        ')qBd4PX@cyclone++BH63ZeV@cyclone',
        '十六夜咲夜 hQgxvvEX@Squall++雾雨魔理沙 FELEUOL6@Squall',
        '天依 \'i[8S`Aw@LuoTianyi++t2W%(s@LuoTianyi',
        '你是茎匙纤堵吗？@otto++你是腕害祝吵吗？@otto',
        'VXBWym><n1adZ6g@XJ联队++=8AAh72hQ1DWwaZ@XJ联队',
        'u75hvWl7-ryx6EL@新纪元++LLo9sBzrImvLHtQ@新纪元',
        '雾山惟助 BAAOVADZ@TigerStar++wt(zEe]T@TigerStar',
        'Starry #YAmFuO0@Arcadia++Starry #cyg490R@Arcadia',
        '1y 0;fJ@紫微垣++3:\\Azxg@紫微垣',
        '立军o0GIG2flx@candle++权计WN13vmJnn@candle',
        '并木芽衣子 #WUNEVETN@暗黑突击++风漂浮灵 #ULTYREWB@暗黑突击',
        'j&%W~J@新纪元++⑤-UsT93dcgqrDO@新纪元',
        '伊甸 en5QiIQ?shadow@魔++春 q1ctsYa@魔',
        '虚境DCRFQNQEN@涵虚++月涌HSCOSAXZW@涵虚',
        '餐腐袁请@昀澤++豹邻跑恒@昀澤',
        '浮光IEGUNVAZQ@涵虚++星垂NMTUYAWNQ@涵虚',
        'b6070773422828狼@otto++鸠逛圣惯帅@otto',
        '畦痰竣片引@Hell++端饲继暂竟@Hell',
        '菩抒絮茁袁@Hell++拨瘤保撕疤@Hell',
        'Patricia FRMQKEKMBXQI@nan++Haiyan SSTPLTGSJOAI@nan',
        '钓虑热赘羔@Shabby_fish++烘断金惫颊@Shabby_fish',
        '② pA7TCuN@新纪元++⑨-MXgoCOds6Glu@新纪元',
        '椎锋akqkxVJq6@candle++天依 VEfVDZVpD@candle'
        
    ];
    var duiyou;
    if (team_type == 1) {
        duiyou = [
'luogu.com.cn/paste/q9h8sdzk@Shabby_fish+diy[45,93,89,64,67,96,94,364]{\"SklClone\": 32,\"SklRevive\": 33,\"SklProtect\": 11,\"SklUpgrade\": 23,\"SklFire\": 6,\"SklPoison\": 2,\"SklCharge\": 20,\"SklCharm\": 84}',
'ilem ?MJxj&<^@LuoTianyi+diy[89,95,94,62,48,93,92,293]{\"SklExchange\": 18,\"SklRevive\": 41,\"SklUpgrade\": 11,\"SklRapid\": 7,\"SklClone\": 68,\"SklProtect\": 19,\"SklDefend\": 12,\"SklReraise\": 71}',
];
    } else if (team_type == 3) {
duiyou=[
'魂魄妖梦 AKG1OENX@Squall+diy[63,89,78,76,42,86,97,343]{\"SklClone\": 31,\"SklHeal\": 3,\"SklThunder\": 1,\"SklShadow\": 96,\"SklHide\": 3,\"SklUpgrade\": 18}',
'Regulus VynkvDehqnzlqQX@Squall+diy[82,91,93,47,43,88,95,340]{\"SklProtect\": 3,\"SklClone\": 30,\"SklHide\": 6,\"SklShadow\": 82,\"SklDefend\": 5,\"SklReraise\": 28}',

]
        
    }  else if (team_type == 2) {
duiyou=[
'梅蒂欣·梅兰可莉 57PL53QA@Squall+diy[82,81,90,78,95,95,91,368]{\"SklExchange\": 2,\"sklHalf\": 11,\"SklClone\": 28,\"SklHeal\": 3,\"SklSlow\": 80}',
'八意永琳 8KE7LKXO@Squall+diy[88,81,85,55,71,90,92,350]{\"SklRapid\": 2,\"SklUpgrade\": 13,\"SklRevive\": 10,\"SklAssassinate\": 12,\"SklCharge\": 1,\"SklReraise\": 27,\"SklExchange\": 58,\"SklClone\": 94}',
]
        
} else if (team_type == 0) {
    duiyou=[
'五箭谏函哄@昀澤+diy[96,66,90,87,86,92,92,289]{\"SklSlow\": 8,\"SklUpgrade\": 11,\"SklExchange\": 11,\"SklRevive\": 31,\"SklClone\": 70,\"SklReraise\": 78}',
'とツウヨゆプピリうくぱニのずぐぶちテろえウ@Squall+diy[90,78,86,76,76,94,94,356]{"SklReraise": 11,"SklZombie": 16,"SklHide": 7,"SklClone": 22,"SklExchange": 15,"SklIron": 70,"SklCounter": 62,"SklUpgrade": 37}',
'⑦ j9AUkzf@新纪元+diy[92,82,90,88,69,83,96,302]{\"SklSlow\": 24,\"SklUpgrade\": 4,\"SklCharm\": 14,\"SklClone\": 66,\"SklReraise\": 86}',
   ]
    }

else
    {
        console.log("工具错误，请与开发者联系。错误信息: 组队人数错误");
        process.exit(0);
    }
    const run_prefix = "!test!\n\n{ply}\n\n{tgt}";
    var sm;
    var cnt;
    var scr;
    
    //console.log('\x1b[31m'+'This is a red text with a yellow background.+\x1b[0m');
    //console.log(sieve);
    //console.log(sieve_screen);
    //console.log("12345");
    for (let lin of lines) {
        
        //if (verbose) console.log(`${lin}`);
        const line = lin.trim();
        
        if (line.trim() === "") {
            continue;
        }
        
        if (line.endsWith("\r")) {
            line = line.slice(0, -1);
        }
        
        if (line.endsWith("\n")) {
            line = line.slice(0, -1);
        }
        let all=[];
        for (let dy of duiyou)
        {
            var newpair;
            newpair=line+"++"+dy;
            sm = 0;
            cnt = 0;
            for (let cur of target) 
                {
                if (cur == newpair) {
                    continue;
                }
                if (
                    line.split("+")[0].trim()==cur.split("++")[0].trim() ||
                    dy.split("+")[0].trim()==cur.split("++")[0].trim() ||
                    line.split("+")[0].trim()==cur.split("++")[1].trim() ||
                    dy.split("+")[0].trim()==cur.split("++")[1].trim()
                ) 
                    continue;
                
                cnt += 1;
                var runs;
                runs = `!test!\n\n\n${newpair.replace("++","\n")}\n\n${cur.replace("++","\n")}`
                
                //console.log(runs);
                const result = await md5_module.win_rate(runs, acc * 100);
                sm += result.win_count / acc;
                //console.log(`${cur} ${result.win_count / acc}%`);
                //fs.appendFileSync(output_file_path, `${newpair} ${cur} ${result.win_count / acc}\n`);
                //if (verbose) fs.appendFileSync(output_file_path,`${newpair.split("++")[0]} ${cur.split("++")[0]} ${result.win_count / acc}\n`);
                //if (verbose) console.log((`${newpair.split("++")[0]} ${cur.split("++")[0]} ${result.win_count / acc}\n`));
                //if (verbose) console.log(`${runs}`);
            }
            scr = (sm / cnt).toFixed(3);
            all.push(Number(scr));
        }
        var res=0;
        if (team_type==0)
        {
            if (Number(all[0])>Number(all[1]) && Number(all[0])>Number(all[2])+1) res=(Number(all[0]));
            else if (Number(all[1])>Number(all[2])+1) res=Number(all[1]); else res=Number(all[2])+1;res*=100;
            if (res >= sieve) fs.appendFileSync(output_file_path, `${res.toFixed(3)} ${line.split('+')[0]}\n`);
        }
        if (team_type==1)
        {
            if (Number(all[1])+0.2>Number(all[0])) res=(Number(all[1])+0.2); else res=Number(all[0]);res*=100;
            if (res >= sieve) fs.appendFileSync(output_file_path, `${res.toFixed(3)} ${line.split('+')[0]}\n`);
        }
        if (team_type==2)
        {
            if (Number(all[1])+1>Number(all[0])) res=(Number(all[1])+1); else res=Number(all[0]);res*=100;
            if (res >= sieve) fs.appendFileSync(output_file_path, `${res.toFixed(3)} ${line.split('+')[0]}\n`);
        }
        if (team_type==3)
        {
            if (Number(all[1])+0.6>Number(all[0])) res=(Number(all[1])+0.6); else res=Number(all[0]);res*=100;
            if (res >= sieve) fs.appendFileSync(output_file_path, `${res.toFixed(3)} ${line.split('+')[0]}\n`);
        }
    }
    
    //fs.appendFileSync(output_file_path, `done\n`);
}

main();

//fs.appendFileSync(output_file_path, `done\n`);