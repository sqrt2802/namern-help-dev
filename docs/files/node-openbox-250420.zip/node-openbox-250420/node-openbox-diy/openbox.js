const process = require("process");
const fs = require("fs");
const path = require("path");
const md5_module = require("./md5.js");
const args = process.argv.slice(2);
const help_msg = `此脚本没有保护措施，长期挂机会爆内存！！！！！\n此脚本没有保护措施，长期挂机会爆内存！！！！！\n此脚本没有保护措施，长期挂机会爆内存！！！！！\n
用法: node.exe legacy.js <开箱类型> <评分精度> <评分阈值> <输入文件> <输出文件>
开箱类型可以是 pp/pd/qp/qd
注意文件会以 UTF-8 编码读入，请检查输入文件的编码！！
评分结果会同步输出到终端以显示进度，如果你想关闭这一输出，请在命令结尾附加 --silent 或 -s
测号字符集里有问号的不要用这个工具处理，否则后果自负。`;
if (args.length < 5 || args.includes("--help") || args.includes("-h")) {
    console.log(help_msg);
    process.exit(0);
}
const file_path = args[3];
const open_type = args[0].toLowerCase();
const output_file_path = args[4];
const acc = Number(args[1]);
const outputmin =Number(args[2]);
const outputmin_screen =Number(args[5]);
var verbose = true;
if (args.includes("--silent") || args.includes("-s")) {
    verbose = false;
}
const open_types = ["pp", "pd", "qp", "qd", "all"];
if (!open_types.includes(open_type)) {
    console.log(`未知的开箱类型: ${open_type}`);
    process.exit(1);
}
if (!fs.existsSync(file_path)) {
    console.log(`不存在的输入文件: ${file_path}`);
    process.exit(1);
}
const file_content = fs.readFileSync(file_path, "utf-8");
const lines = file_content.split("\n");
async function main() {
    //console.log("12345");
    for (let line of lines) {
        
        if (line.trim() === "") {
            continue;
        }
        if (line.endsWith("\r")) {
            line = line.slice(0, -1);
        }
        if (line.endsWith("\n")) {
            line = line.slice(0, -1);
        }
        
        let runs = "";
        if (open_type=="qp" || open_type=="all") runs=`!test!\n!\n\n${line.replace("++","\n")}`;
        if (open_type=="qd") runs=`!test!\n!\n\n${line.replace("++","\n")}\n${line.replace("++","\n")}`;
        if (open_type=="pp") runs=`!test!\n\n\n${line.replace("++","\n")}`;
        if (open_type=="pd") runs=`!test!\n\n\n${line.replace("++","\n")}\n${line.replace("++","\n")}`;

        const result = await md5_module.score(runs, acc * 100);

        const win_rate = (result.score * 10000) / (acc * 100);
        if (win_rate>=outputmin)
        {
            if (open_type=='all')
            {
                runs=`!test!\n!\n\n${line.replace("++","\n")}\n${line.replace("++","\n")}`;
                const result2 = await md5_module.score(runs, acc * 100);
                const win_rate2 = (result2.score * 10000) / (acc * 100);
                
                runs=`!test!\n\n\n${line.replace("++","\n")}`;
                const result3 = await md5_module.score(runs, acc * 100);
                const win_rate3 = (result3.score * 10000) / (acc * 100);
                
                runs=`!test!\n\n\n${line.replace("++","\n")}\n${line.replace("++","\n")}`;
                const result4 = await md5_module.score(runs, acc * 100);
                const win_rate4 = (result4.score * 10000) / (acc * 100);

                
                if (verbose && win_rate>=outputmin_screen) console.log(`${line} ${win_rate} ${win_rate2} ${win_rate3} ${win_rate4}`);
                fs.appendFileSync(output_file_path, `${win_rate} ${win_rate2} ${win_rate3} ${win_rate4} ${line}\n`);

            } else 
            {
                if (verbose && win_rate>=outputmin_screen) console.log(`${line} ${win_rate}`);
                fs.appendFileSync(output_file_path, `${win_rate} ${line}\n`);
            }
            
        }
    }
}
main();
