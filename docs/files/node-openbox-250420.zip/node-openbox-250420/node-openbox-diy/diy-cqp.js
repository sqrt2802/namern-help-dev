"use strict";

const process = require("process");
const fs = require("fs");
const path = require("path");
const readline = require("readline");
const md5_module = require("./md5.js");

const args = process.argv.slice(2);
const file_path = args[3];
const team_size = Number(args[0]);
const output_file_path = args[4];
const acc = Number(args[1]);
const sieve = Number(args[2]);
const sieve_screen = Number(args[5]);

const file_content = fs.readFileSync(file_path, "utf-8");
const lines = file_content.split("\n");

const results = [];
var verbose = true;
if (args.includes("--silent") || args.includes("-s")) {
    verbose = false;
}

if (!fs.existsSync(file_path)) {
    console.log("工具错误，请与开发者联系。错误信息: 输入文件不存在");
    process.exit(0);
}

async function main() {
    var target;
    if (team_size == 1) {
        target = [
'<αβ>-02pjt42k@ReturnVoid',
'飞雪PSODKKXWP@涵虚',
'虚境-4xtrv36e@涵虚',
'<βε>-lxecl3g6@ReturnVoid',
'十六夜咲夜 imIuZYJk@Squall',
'爱丽丝·玛格特洛依德 G26FRAL0@Squall',
'光YLqKf5rv9EU9lnc@Squall',
'魂魄妖梦 AKG1OENX@Squall',
'郭娱戈宏帅@otto',
'大家好啊，我是蟆猎命说@otto',
'\\Empire\\-692175165208@\\XIV\\-14',
'Momomomo #YAORzaY@Arcadia',
'Momo #L9GHU8F@Arcadia',
'CtC7gL9JNpvNpOl@新纪元',
'② vYtp0F-@新纪元',
'肪袍首阱丹@Hell',
'rkYDjfxB@coat',
'vRuH:z@耗子尾汁',
'史莱德 #XPMTVPKY@暗黑突击',
'\`I!.lf@紫微垣',
'涵虚不等式 PFVKEUPBU@TigerStar',
'癌细胞 Qgu35DIL[Q8us/3@TigerStar',
'wt(zEe]T@TigerStar',
'0000000I0bNQDRS@aaa',
'00000000MOYffOK@aaa',
'0000001p5tE2pMs@aaa',
'0000000hjMO5Zv5@aaa',
'Rick QUJTCGUVGHIJ@nan',
'U>7D3Ol7uWKIfTC@XJ联队',
'Lumos dtGoP!RM@Shabby_fish',
'Neverland RjRNrl4YV@candle',
'天依 \'i[8S`Aw@LuoTianyi'
];
    } else if (team_size == 2) {
        target = [
'luogu.com.cn/paste/q9h8sdzk@Shabby_fish+Riddikulus Cft~F`gf@Shabby_fish',
'Accio #LD5MtqO8@Shabby_fish+Alohomora !p}hh.\'h@Shabby_fish',
'Mortis KuyCrISZcN@🥒+Rin GcXcnaritM@🥒',
'CtC7gL9JNpvNpOl@新纪元+aGIu6296EcGwMyG@新纪元',
'とツウヨゆプピリうくぱニのずぐぶちテろえウ@Squall+東方謬葷負@Squall',
'双向})DETWQK@LuoTianyi+ilem ?MJxj&<^@LuoTianyi',
'<αλ>-8ed1q4wi@ReturnVoid+<ακ>-5jmt0g6o@ReturnVoid',
'あはらけぷまぬ@新纪元+φκδογωψπγν@新纪元',
'谏征T2unNudfa@candle+权计WN13vmJnn@candle',
'涵虚不等式 PFVKEUPBU@TigerStar+刷屏托腮 FXLNIBHI@TigerStar',
'Armageddon wapZxwOGhprYJaz@Squall+Tairitsu AvPj92jhIXrySBT@Squall',
'Sayaka gh8yaICYo@candle+Arghena vCNU5UqWM@candle',
'小恶魔 XZQD019D@Squall+東方熷戨环@Squall',
'Guruthos {&wTWLCC(H!p@流浪冒险者+Tirn y_[yNJ#jq"9r@流浪冒险者',
'隅骨叙壁帅@otto+卧槽，策刽旗磕狗@otto',
'boH-Hv0sCoHPtF7@新纪元+ηψτξσγθηνμ@新纪元',
'避籍司前帅@otto+不，了了了不了了活活不活行活不行了，了@otto',
'阿努比斯 #QBLWADEI@暗黑突击+三好纱南 #RUOKYSEC@暗黑突击',
'吸血魔兽 #OPZDENED@暗黑突击+大西由里子 #NCPEGNID@暗黑突击',
'二胡映月惆匈镸 #02Kp0M80@爱+Alice bMNwWTMhaD@爱',
'很去乳葬锰@Hell+q1)9Pd|@Hell',
'浮光IEGUNVAZQ@涵虚+星垂NMTUYAWNQ@涵虚',
'② pA7TCuN@新纪元+⑨-MXgoCOds6Glu@新纪元',
'𝟶𝟹𝙵𝚉𝚃𝚈𝟻𝚁@昀澤+三拳仾皚䕼@昀澤',
'0000000aodfsFjT@aaa+0000001ta0z4ehz@aaa',
'無名钝抑漏阻@神之长子leo+神之长子leo S7UGN2ELAKWM@神之长子leo',
'リコベペムダヅ@新纪元+xvQntnwvp9d0-rh@新纪元',
'=8AAh72hQ1DWwaZ@XJ联队+7eDAtZbnBN5R31>@XJ联队',
'qwq 挣棉咨藐@芒萁+qwq 棘酵汪慢@芒萁',
'<αγ>-ll33q4sv@ReturnVoid+<βη>-pizztqpr@ReturnVoid',
'0000000RsY6L2Wn@aaa+0000001Ki24AVw0@aaa',
'🧄🫑🫛🍓🥕🍋🥝🥬🍌🍈🍆🍋🍋🫑🍉@🥒+OnlyYau-ofgbuzMKRE@🥒',
'忘归 GXUOZBOZ@TigerStar+雾山惟助 BAAOVADZ@TigerStar',
'星熊勇仪 4SHMF1UK@Squall+莉莉霍瓦特 H9UEBBVD@Squall',
'Nisha GADTDOSXVJEI@nan+Gay ULDIDSMWCXVJ@nan'


        ];
    }  else
    {
        console.log("工具错误，请与开发者联系。错误信息: 组队人数错误");
        process.exit(0);
    }
    var sm;
    var cnt;
    var scr;
    for (let lin of lines) {
        
        //if (verbose) console.log(`${lin}`);
        const line = lin.trim();
        
        if (verbose) fs.appendFileSync(output_file_path,`${line.split("+")[0]} 1`);
        if (line.trim() === "") {
            continue;
        }
        
        if (verbose) fs.appendFileSync(output_file_path,`${line.split("+")[0]} 2`);
        if (line.endsWith("\r")) {
            line = line.slice(0, -1);
        }
        
        if (verbose) fs.appendFileSync(output_file_path,`${line.split("+")[0]} 3`);
        if (line.endsWith("\n")) {
            line = line.slice(0, -1);
        }
        
        if (verbose) fs.appendFileSync(output_file_path,`${line.split("+")[0]} 4`);
        sm = 0;
        cnt = 0;
        for (let cur of target) 
            {
            if (cur == line) {
                continue;
            }
            if (team_size == 2) {
                if (
                    line.split("+")[0].trim()==cur.split("+")[0].trim() ||
                    line.split("+")[3].trim()==cur.split("+")[0].trim() ||
                    line.split("+")[0].trim()==cur.split("+")[1].trim() ||
                    line.split("+")[3].trim()==cur.split("+")[1].trim()
                ) {
                    continue;
                }
            }
            cnt += 1;
            var runs = `!test!\n\n\n${line.replace("++","\n")}\n\n${cur.replace("+","\n")}`
            const result = await md5_module.win_rate(runs, acc * 100);
            sm += result.win_count / acc;

            if (verbose) console.log(output_file_path,`${line} ${cur} ${result.win_count / acc}\n`);

        }
        scr = (sm / cnt).toFixed(3);
        if (scr >= sieve_screen) console.log(`${line}:平均胜率:${sm}/${cnt}= ${scr}%`);
        if (scr >= sieve) {
            fs.appendFileSync(output_file_path, `${scr} ${line}\n`);
        }
    }
    
    //fs.appendFileSync(output_file_path, `done\n`);
}

main();

//fs.appendFileSync(output_file_path, `done\n`);