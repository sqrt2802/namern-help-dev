"use strict";
const process = require("process");
const fs = require("fs");
const path = require("path");
const readline = require("readline");
const md5_module = require("./md5.js");

const args = process.argv.slice(2);
const file_path = args[3];
const team_type = Number(args[0]);
const output_file_path = args[4];
const acc = Number(args[1]);
const sieve = Number(args[2]);
const sieve_screen = Number(args[5]);

const file_content = fs.readFileSync(file_path, "utf-8");
const lines = file_content.split("\n");

const results = [];
var verbose = true;
if (args.includes("--silent") || args.includes("-s")) {
    verbose = false;
}

if (!fs.existsSync(file_path)) {
    console.log("工具错误，请与开发者联系。错误信息: 输入文件不存在");
    process.exit(0);
}

async function main() {
    var target;
    target = ['二胡映月惆匈镸 #02Kp0M80@爱++Alice bMNwWTMhaD@爱',
'谏征T2unNudfa@candle++权计WN13vmJnn@candle',
'很去乳葬锰@Hell++q1)9Pd|@Hell',
'浮光IEGUNVAZQ@涵虚++星垂NMTUYAWNQ@涵虚',
'無名钝抑漏阻@神之长子leo++神之长子leo S7UGN2ELAKWM@神之长子leo',
'Nisha GADTDOSXVJEI@nan++Gay ULDIDSMWCXVJ@nan',
'Mortis KuyCrISZcN@🥒++Rin GcXcnaritM@🥒',
'🧄🫑🫛🍓🥕🍋🥝🥬🍌🍈🍆🍋🍋🫑🍉@🥒++OnlyYau-ofgbuzMKRE@🥒',
'qwq 挣棉咨藐@芒萁++qwq 棘酵汪慢@芒萁',
'Sayaka gh8yaICYo@candle++Arghena vCNU5UqWM@candle',
'隅骨叙壁帅@otto++卧槽，策刽旗磕狗@otto',
'Guruthos {&wTWLCC(H!p@流浪冒险者++Tirn y_[yNJ#jq\"9r@流浪冒险者',
'0000000aodfsFjT@aaa++0000001ta0z4ehz@aaa',
'吸血魔兽 #OPZDENED@暗黑突击++大西由里子 #NCPEGNID@暗黑突击',
'0000000RsY6L2Wn@aaa++0000001Ki24AVw0@aaa',
'とツウヨゆプピリうくぱニのずぐぶちテろえウ@Squall++東方謬葷負@Squall',
'リコベペムダヅ@新纪元++xvQntnwvp9d0-rh@新纪元',
'CtC7gL9JNpvNpOl@新纪元++aGIu6296EcGwMyG@新纪元',
'あはらけぷまぬ@新纪元++φκδογωψπγν@新纪元',
'阿努比斯 #QBLWADEI@暗黑突击++三好纱南 #RUOKYSEC@暗黑突击',
'避籍司前帅@otto++不，了了了不了了活活不活行活不行了，了@otto',
'<αγ>-ll33q4sv@ReturnVoid++<βη>-pizztqpr@ReturnVoid',
'=8AAh72hQ1DWwaZ@XJ联队++7eDAtZbnBN5R31>@XJ联队',
'Armageddon wapZxwOGhprYJaz@Squall++Tairitsu AvPj92jhIXrySBT@Squall',
'<αλ>-8ed1q4wi@ReturnVoid++<ακ>-5jmt0g6o@ReturnVoid',
'小恶魔 XZQD019D@Squall++東方熷戨环@Squall',
'𝟶𝟹𝙵𝚉𝚃𝚈𝟻𝚁@昀澤++三拳仾皚䕼@昀澤',
'boH-Hv0sCoHPtF7@新纪元++ηψτξσγθηνμ@新纪元',
'双向})DETWQK@LuoTianyi++ilem ?MJxj&<^@LuoTianyi',
'忘归 GXUOZBOZ@TigerStar++雾山惟助 BAAOVADZ@TigerStar',
'星熊勇仪 4SHMF1UK@Squall++莉莉霍瓦特 H9UEBBVD@Squall',
'涵虚不等式 PFVKEUPBU@TigerStar++刷屏托腮 FXLNIBHI@TigerStar',
'Accio #LD5MtqO8@Shabby_fish++Alohomora !p}hh.\'h@Shabby_fish',
'② pA7TCuN@新纪元++⑨-MXgoCOds6Glu@新纪元',
'luogu.com.cn/paste/q9h8sdzk@Shabby_fish++Riddikulus Cft~F`gf@Shabby_fish'];
    var duiyou;
    if (team_type == 2) {
        duiyou = [
'天依 \'i[8S`Aw@LuoTianyi+diy[90,89,98,94,96,95,90,335]{\"SklPoison\":10,\"SklAbsorb\":16,\"SklFire\":2,\"SklCritical\":7,\"SklQuake\":1,\"SklHaste\":4,\"SklDisperse\":78,\"SklCounter\":26}',
'C(/y&)@暗黑突击+diy[99,84,87,89,96,92,90,375]{\"SklDisperse\":9,\"SklCurse\":7,\"SklBerserk\":10,\"SklMerge\":3,\"SklReflect\":21,\"SklCounter\":8,\"SklQuake\":70}',
'弼䫉诜㾂膼@昀澤+diy[93,92,94,82,97,94,86,358]{\"SklDisperse\":13,\"SklExchange\":24,\"SklShield\":7,\"SklIce\":10,\"SklHide\":4,\"SklQuake\":66,\"SklMerge\":11,\"SklUpgrade\":26}',
'0000000aodfsFjT@aaa+diy[97,85,98,95,81,91,95,338]{\"SklExchange\":9,\"SklCritical\":25,\"SklReflect\":14,\"SklBerserk\":3,\"SklMerge\":6,\"SklIce\":48,\"SklReraise\":58}',
'封焔の067750774622秒@Squall+diy[92,87,98,96,90,85,86,375]{\"SklSummon\":2,\"SklIce\":26,\"SklZombie\":6,\"SklShield\":2,\"SklIron\":58,\"SklProtect\":14,\"SklHide\":10}',
'星熊勇仪 4SHMF1UK@Squall+diy[94,87,94,93,93,89,89,333]{\"SklCurse\":21,\"SklMerge\":17,\"SklIron\":22,\"SklDefend\":3,\"SklFire\":2,\"SklProtect\":32,\"SklCounter\":5,\"SklDisperse\":74}',
'5UWSX0DGRE5pTA9@新纪元+diy[96,86,97,95,70,91,90,347]{\"SklCharm\":8,\"SklShadow\":32,\"SklProtect\":31,\"SklReflect\":15,\"SklAbsorb\":9,\"SklIron\":12,\"SklCritical\":17,\"SklDisperse\":62}',
'愞㢯老海@昀澤+diy[84,83,95,96,90,98,80,356]{\"SklAbsorb\":8,\"SklMerge\":2,\"SklCharm\":15,\"SklQuake\":11,\"SklCritical\":7,\"SklReraise\":26,\"SklReflect\":6,\"SklIce\":54,\"SklDefend\":55}',
'森近霖之助 EXJJCI3N@Squall+diy[90,88,97,81,77,93,95,354]{\"SklDisperse\":33,\"SklCounter\":6,\"SklRapid\":7,\"SklExchange\":6,\"SklDefend\":22,\"SklHeal\":1,\"SklHaste\":54,\"SklProtect\":40}',
'boH-Hv0sCoHPtF7@新纪元+diy[68,84,95,96,86,82,90,352]{\"SklDefend\":15,\"SklSlow\":21,\"SklDisperse\":84,\"SklZombie\":5,\"SklReraise\":56,\"SklUpgrade\":24}',
'Sayaka gh8yaICYo@candle+diy[83,82,91,95,98,96,86,335]{\"SklQuake\":22,\"SklAbsorb\":3,\"SklSlow\":19,\"SklReraise\":16,\"SklIron\":60,\"SklProtect\":55}',
'② pA7TCuN@新纪元+diy[97,78,95,90,88,92,87,363]{\"SklAbsorb\":14,\"SklShield\":6,\"SklIron\":22,\"SklSlow\":1,\"SklReraise\":4,\"SklBerserk\":48,\"SklDefend\":60}',
'くるぶっこちゃん #055655320257@新纪元+diy[89,86,94,98,65,97,88,323]{\"SklDefend\":23,\"SklClone\":25,\"SklDisperse\":4,\"SklUpgrade\":5,\"SklIron\":16,\"SklExchange\":16,\"SklReraise\":80}',
'⑨ fSfaEC6@新纪元+diy[94,84,92,97,88,91,90,375]{\"SklCritical\":5,\"SklDefend\":23,\"SklSlow\":12,\"SklSummon\":2,\"SklCharm\":6,\"SklMerge\":22,\"SklHalf\":58},
とツウヨゆプピリうくぱニのずぐぶちテろえウ@Squall+diy[90,78,86,76,76,94,94,356]{\"SklReraise\":11,\"SklZombie\":16,\"SklHide\":7,\"SklClone\":22,\"SklExchange\":15,\"SklIron\":70,\"SklCounter\":62,\"SklUpgrade\":37},
'Avada_Kedavra #IR1ePbBR@Shabby_fish+diy[84,89,98,88,92,96,87,336]{\"SklHaste\":12,\"SklAccumulate\":5,\"SklQuake\":3,\"SklReraise\":25,\"SklIce\":27,\"SklExchange\":1,\"SklHeal\":8,\"SklCharm\":62,\"SklCounter\":11,\"SklReflect\":22,\"SklProtect\":37}',
'Finite_Incantatem JJhw=omb@Shabby_fish+diy[96,83,98,84,79,92,94,373]{\"SklClone\":10,\"SklExchange\":7,\"SklSlow\":68,\"SklMerge\":58,\"SklDefend\":2}',
'刷屏托腮 FXLNIBHI@TigerStar+diy[76,88,88,92,90,97,98,354]{\"SklFire\":2,\"SklMerge\":19,\"SklAccumulate\":10,\"SklIce\":11,\"SklQuake\":78,\"SklDefend\":44}',
'天演ek8IudYmCpiZ@橙红耀阳+diy[85,96,95,97,93,83,80,357]{\"SklRevive\":30,\"SklIron\":12,\"SklDefend\":16,\"SklReraise\":47,\"SklIce\":76}',
'爱丽丝 #D17rNbyH@thb580+diy[89,90,94,92,95,91,97,309]{\"SklShadow\":4,\"SklPoison\":27,\"SklReraise\":24,\"SklBerserk\":21,\"SklZombie\":12,\"SklReflect\":28,\"SklIron\":78,\"SklShield\":2}'


];
    } else if (team_type == 1) {
duiyou=[
'^o^ Fm$UD2EM@KODU大好人+diy[61,88,97,94,91,94,80,344]{\"SklPoison\":19,\"SklAbsorb\":1,\"SklUpgrade\":21,\"SklClone\":1,\"SklAssassinate\":92,\"SklMerge\":56}',
'⑨-MXgoCOds6Glu@新纪元+diy[62,93,95,85,98,92,94,327]{\"SklCounter\":8,\"SklZombie\":5,\"SklAssassinate\":90,\"SklHide\":10,\"SklMerge\":49}',
'Wispy #6uttTRg@Arcadia+diy[78,92,93,55,97,92,84,354]{\"SklUpgrade\":13,\"SklHeal\":8,\"SklCharm\":5,\"SklAssassinate\":94,\"SklHide\":6,\"SklZombie\":46,\"SklShield\":26}',
'伊甸 en5QiIQ?shadow@魔+diy[55,88,91,82,85,93,85,350]{\"SklCounter\":8,\"SklAssassinate\":100,\"SklReraise\":3,\"SklZombie\":16,\"SklMerge\":52}',
'镜华 CWXJVQRP@公主连结+diy[61,80,98,95,90,93,89,318]{\"SklQuake\":4,\"SklShadow\":3,\"SklAccumulate\":10,\"SklRevive\":26,\"SklMerge\":60,\"SklAssassinate\":90}',
'Tirn y_[yNJ#jq\"9r@流浪冒险者+diy[71,83,98,69,93,96,92,351]{\"SklCharm\":2,\"SklShadow\":16,\"SklAssassinate\":88,\"SklDefend\":14,\"SklZombie\":40}',
'Hell 迚昫餅@名字竞技场+diy[54,82,92,60,94,89,90,321]{\"SklQuake\":1,\"SklShield\":10,\"SklDefend\":5,\"SklCounter\":2,\"SklAssassinate\":100,\"SklReraise\":3,\"SklMerge\":52,\"SklUpgrade\":30}',
'b6070773422828狼@otto+diy[58,88,96,66,92,89,92,341]{\"SklDisperse\":9,\"SklRevive\":3,\"SklClone\":19,\"SklHalf\":16,\"SklAssassinate\":84,\"SklReraise\":58}',
'00000040k0wLBzO@aaa+diy[81,93,84,73,83,97,84,314]{\"SklZombie\":11,\"SklRevive\":14,\"SklAssassinate\":90,\"SklDefend\":30,\"SklShield\":78}',
'ぽげぱてるづじ@新纪元+diy[72,83,97,91,93,98,92,347]{\"SklClone\":5,\"SklBerserk\":10,\"SklHalf\":13,\"SklHeal\":3,\"SklCurse\":1,\"SklZombie\":42,\"SklAssassinate\":78}',
]
        
    }  else if (team_type == 3) {
duiyou=[
    '十六夜咲夜 hQgxvvEX@Squall+diy[88,78,95,96,92,90,84,361]{\"SklExchange\": 6,\"SklReflect\": 25,\"SklCurse\": 10,\"SklQuake\": 84,\"SklUpgrade\": 2}',
'雾山惟助 BAAOVADZ@TigerStar+diy[72,95,94,81,98,85,92,353]{\"SklDefend\": 18,\"SklSlow\": 1,\"SklReraise\": 10,\"SklCharge\": 9,\"SklQuake\": 68,\"SklDisperse\": 80}',
'莉莉霍瓦特 H9UEBBVD@Squall+diy[71,84,97,62,94,93,92,343]{\"SklMerge\": 14,\"SklUpgrade\": 25,\"SklHide\": 3,\"SklSummon\": 2,\"SklProtect\": 22,\"SklClone\": 30,\"sklHalf\": 56,\"SklQuake\": 82}',
'C(/y&)@暗黑突击+diy[99,84,87,89,96,92,90,375]{\"SklDisperse\": 9,\"SklCurse\": 7,\"SklBerserk\": 10,\"SklMerge\": 3,\"SklReflect\": 21,\"SklCounter\": 8,\"SklQuake\": 70}',
'刷屏托腮 FXLNIBHI@TigerStar+diy[76,88,88,92,90,97,98,354]{\"SklFire\": 2,\"SklMerge\": 19,\"SklAccumulate\": 10,\"SklIce\": 11,\"SklQuake\": 78,\"SklDefend\": 44}',
'jfPRe106zwFWnDW@XJ联队+diy[85,90,86,98,94,83,95,348]{\"SklReflect\": 10,\"SklRapid\": 15,\"SklHide\": 7,\"SklMerge\": 16,\"SklQuake\": 70,\"SklCounter\": 56}',
'你是腕害祝吵吗？@otto+diy[64,77,95,92,97,91,88,364]{\"SklZombie\": 25,\"SklDefend\": 13,\"SklSlow\": 6,\"SklExchange\": 10,\"SklClone\": 1,\"SklHeal\": 20,\"SklQuake\": 94}',
'雾雨魔理沙 FELEUOL6@Squall+diy[73,78,96,88,93,99,85,325]{\"SklIron\": 7,\"SklExchange\": 14,\"SklBerserk\": 7,\"SklQuake\": 90,\"SklProtect\": 14,\"SklCounter\": 26,\"SklReflect\": 62}',
'归墟CAHHOTHNE@涵虚+diy[58,87,95,89,95,97,94,327]{\"SklSlow\": 17,\"SklAccumulate\": 5,\"SklHide\": 5,\"SklProtect\": 3,\"SklExchange\": 3,\"SklFire\": 7,\"sklHalf\": 24,\"SklQuake\": 88}',
'opWS>O76kKbeyzp@XJ联队+diy[73,83,97,91,95,98,90,335]{\"SklBerserk\": 5,\"SklSummon\": 2,\"SklZombie\": 5,\"SklQuake\": 88,\"SklMerge\": 28}',
'BH63ZeV@cyclone+diy[92,87,96,93,88,98,86,344]{\"SklCounter\": 5,\"SklShadow\": 23,\"SklAccumulate\": 3,\"sklHalf\": 14,\"SklClone\": 2,\"SklUpgrade\": 8,\"SklIce\": 6,\"SklDefend\": 47,\"SklQuake\": 48}',
'<βη>-pizztqpr@ReturnVoid+diy[83,96,92,90,94,97,89,322]{\"SklUpgrade\": 21,\"SklIce\": 5,\"SklAbsorb\": 3,\"SklRevive\": 2,\"SklMerge\": 13,\"SklCurse\": 6,\"SklReraise\": 13,\"SklQuake\": 80,\"SklHide\": 16}',
'姆姆欧姆啊姆欧手手一欧姆姆米欧姆手比啊哈比@otto+diy[89,95,88,95,88,94,87,353]{\"SklQuake\": 96,\"SklProtect\": 10}',
'I3TvXgfqq1giN92@新纪元+diy[91,92,95,98,91,88,79,351]{\"SklCharm\": 10,\"SklDisperse\": 9,\"SklPoison\": 6,\"SklQuake\": 76,\"SklProtect\": 4,\"SklDefend\": 40}',
'u75hvWl7-ryx6EL@新纪元+diy[71,78,94,98,89,95,91,345]{\"SklCurse\": 8,\"SklAccumulate\": 19,\"SklQuake\": 80,\"SklMerge\": 11,\"SklHide\": 6,\"SklZombie\": 25,\"SklProtect\": 2,\"SklReflect\": 8}',
'琪斯美 DEKUUU5K@Squall+diy[66,94,94,89,98,95,85,335]{\"SklExchange\": 17,\"SklSlow\": 2,\"SklHaste\": 9,\"sklHalf\": 28,\"SklCharm\": 8,\"SklReflect\": 5,\"SklQuake\": 88,\"SklShield\": 4}',
'我早上本来应该吃4858768296675个韭菜盒子@otto+diy[86,89,91,92,85,95,93,351]{\"SklExchange\": 31,\"SklPoison\": 11,\"SklAccumulate\": 33,\"SklHaste\": 5,\"SklQuake\": 52,\"SklDefend\": 7,\"SklCounter\": 46}',
'猎豹痰片引 GPGWIFEI@Hell+diy[86,89,90,97,93,88,85,353]{\"SklReflect\": 11,\"SklDisperse\": 7,\"SklAssassinate\": 5,\"SklZombie\": 12,\"SklQuake\": 82,\"SklReraise\": 26}',
'The DaXMAKzponaSXMw@Squall+diy[63,88,91,98,97,94,90,329]{\"SklHide\": 16,\"SklCurse\": 15,\"SklMerge\": 17,\"SklCounter\": 26,\"SklShadow\": 14,\"SklQuake\": 80}'

]
        
} else if (team_type == 4) {
    duiyou=[
        '十六夜咲夜#EF4V65LZD4OGGZG@Squall+diy[74,90,92,96,80,88,93,333]{\"SklBerserk\": 11,\"SklDisperse\": 7,\"SklShadow\": 14,\"SklZombie\": 10,\"SklThunder\": 7,\"SklClone\": 27,\"SklReraise\": 74,\"SklExchange\": 58}',
        'とツウヨゆプピリうくぱニのずぐぶちテろえウ@Squall+diy[90,78,86,76,76,94,94,356]{\"SklReraise\": 11,\"SklZombie\": 16,\"SklHide\": 7,\"SklClone\": 22,\"SklExchange\": 15,\"SklIron\": 70,\"SklCounter\": 62,\"SklUpgrade\": 37}'

    ]
            
    }

else
    {
        console.log("工具错误，请与开发者联系。错误信息: 组队人数错误");
        process.exit(0);
    }
    const run_prefix = "!test!\n\n{ply}\n\n{tgt}";
    var sm;
    var cnt;
    var scr;
    
    //console.log('\x1b[31m'+'This is a red text with a yellow background.+\x1b[0m');
    //console.log(sieve);
    //console.log(sieve_screen);
    //console.log("12345");
    for (let lin of lines) {
        
        //if (verbose) console.log(`${lin}`);
        const line = lin.trim();
        
        if (line.trim() === "") {
            continue;
        }
        
        if (line.endsWith("\r")) {
            line = line.slice(0, -1);
        }
        
        if (line.endsWith("\n")) {
            line = line.slice(0, -1);
        }
        let all=[];
        for (let dy of duiyou)
        {
            var newpair;
            newpair=line+"++"+dy;
            sm = 0;
            cnt = 0;
            for (let cur of target) 
                {
                if (cur == newpair) {
                    continue;
                }
                if (
                    line.split("+")[0].trim()==cur.split("++")[0].trim() ||
                    dy.split("+")[0].trim()==cur.split("++")[0].trim() ||
                    line.split("+")[0].trim()==cur.split("++")[1].trim() ||
                    dy.split("+")[0].trim()==cur.split("++")[1].trim()
                ) 
                    continue;
                
                cnt += 1;
                var runs;
                runs = `!test!\n\n\n${newpair.replace("++","\n")}\n\n${cur.replace("++","\n")}`
                
                //console.log(runs);
                const result = await md5_module.win_rate(runs, acc * 100);
                sm += result.win_count / acc;
                //console.log(`${cur} ${result.win_count / acc}%`);
                //fs.appendFileSync(output_file_path, `${newpair} ${cur} ${result.win_count / acc}\n`);
                //if (verbose) fs.appendFileSync(output_file_path,`${newpair.split("++")[0]} ${cur.split("++")[0]} ${result.win_count / acc}\n`);
                //if (verbose) console.log((`${newpair.split("++")[0]} ${cur.split("++")[0]} ${result.win_count / acc}\n`));
                //if (verbose) console.log(`${runs}`);
            }
            scr = (sm / cnt).toFixed(3);
            all.push(Number(scr));
            if (verbose && sm/cnt>=45) console.log('\x1b[90m'+`${line.split('+')[0]+'+'+dy.split('+')[0]}:平均胜率:${sm.toFixed(2)}/${cnt}= ${scr}%`+'\x1b[0m');
            //if (scr >= sieve_screen) console.log(`${newpair}:平均胜率:${sm}/${cnt}= ${scr}%`);
        }
        var res=0;
        if (team_type==1)
        {
            
        all.sort((a, b) => b - a);
            res=Number(all[0])+Number(all[1])+Number(all[2]);
            //console.log("12345");
            //console.log(res);
            //console.log('%cThis is a red text with a yellow background.', 'color: red; background-color: yellow;');
            if (res >= sieve_screen+4) console.log('\x1b[31m'+`${line.split('+')[0]} 评分: ${all[0].toFixed(3)} + ${all[1].toFixed(3)} + ${all[2].toFixed(3)} = ${res.toFixed(3)}%`+'\x1b[0m')
            //else if (res >= sieve_screen+3) console.log('\x1b[0m'+`${line} 评分: ${all[0].toFixed(3)} + ${all[1].toFixed(3)} + ${all[2].toFixed(3)} = ${res.toFixed(3)}%`+'\x1b[0m')
            else if (res >= sieve_screen) console.log('\x1b[0m'+`${line.split('+')[0]} 评分: ${all[0].toFixed(3)} + ${all[1].toFixed(3)} + ${all[2].toFixed(3)} = ${res.toFixed(3)}%`+'\x1b[0m')
                
            if (res >= sieve) fs.appendFileSync(output_file_path, `${res.toFixed(3)} ${line.split('+')[0]}\n`);
        }
        else if (team_type==4)
            {
                if (Number(all[0])+1>Number(all[1])) res=(Number(all[0])+1); else res=Number(all[1]);
                //console.log("12345");
                //console.log(res);
                //console.log('%cThis is a red text with a yellow background.', 'color: red; background-color: yellow;');
                if (res >= sieve_screen+4) console.log('\x1b[31m'+`${line.split('+')[0]} 评分: max( ${all[0].toFixed(3)} + 1, ${all[1].toFixed(3)} ) = ${res.toFixed(3)}%`+'\x1b[0m')
                //else if (res >= sieve_screen+3) console.log('\x1b[0m'+`${line} 评分: ${all[0].toFixed(3)} + ${all[1].toFixed(3)} + ${all[2].toFixed(3)} = ${res.toFixed(3)}%`+'\x1b[0m')
                else if (res >= sieve_screen) console.log('\x1b[0m'+`${line.split('+')[0]} 评分: max( ${all[0].toFixed(3)} + 1, ${all[1].toFixed(3)} ) = ${res.toFixed(3)}%`+'\x1b[0m')
                    
                if (res >= sieve) fs.appendFileSync(output_file_path, `${res.toFixed(3)} ${line.split('+')[0]}\n`);
            }
        else 
        {
            
            all.sort((a, b) => b - a);
            res=all[0]+all[1]+all[2]+all[3]+all[4];
            
            if (res >= sieve_screen+4) console.log('\x1b[31m'+`${line.split('+')[0]} 评分: ${all[0].toFixed(3)} + ${all[1].toFixed(3)} + ${all[2].toFixed(3)} + ${all[3].toFixed(3)} + ${all[4].toFixed(3)} = ${res.toFixed(3)}%`+'\x1b[0m')
            else if (res >= sieve_screen) console.log('\x1b[0m'+`${line.split('+')[0]} 评分: ${all[0].toFixed(3)} + ${all[1].toFixed(3)} + ${all[2].toFixed(3)} + ${all[3].toFixed(3)} + ${all[4].toFixed(3)} = ${res.toFixed(3)}%`+'\x1b[0m')
                
            if (res >= sieve) fs.appendFileSync(output_file_path, `${res.toFixed(3)} ${line.split('+')[0]}\n`);
        }
    }
    
    //fs.appendFileSync(output_file_path, `done\n`);
}

main();

//fs.appendFileSync(output_file_path, `done\n`);