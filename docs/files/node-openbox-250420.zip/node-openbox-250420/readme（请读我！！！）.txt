打扫古战场的时候最终决定把 sqrt 之前写的那几个东西给删了，只保留了 example.js。
无论如何，还是非常感谢 sqrt 对初期 node 开箱的贡献。
使用说明见 node.pdf。