// md5.js 使用方法示例
const md5js=require("./md5.js"); // 导入 md5.js 模块，注意不能缺失 assets 文件夹
async function main(){ // 主函数需要设为 async 属性才可使用 await
    var text,acc; // text 按游戏网页输入框的格式填入
    acc=10; // 精度 10%

    // 单挑和组队对战
    text="1\n2\n\na\nb"
    const result1=await md5js.fight(text);
    console.log(result1.source_plr); // 团战结果返回值为赢家队伍中的任意一个名字

    // 测试胜率
    text="!test!\n\n1\n\n2";
    const result3=await md5js.win_rate(text,acc*100);
    console.log(result3.win_count/acc);

    // 测试评分
    text="!test!\n\n1";
    const result2=await md5js.score(text,acc*100);
    console.log(result2.score*100/acc);
}
main();
