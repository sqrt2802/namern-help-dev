#include<bits/stdc++.h>
using namespace std;
map<string, int> Map;
int score;
string name;
int tmp;
int s1,s2,s3;
int type;
set< pair<int, string> > S;
string kkk(string o)
{
    string p[2];int l=0;p[0]="";p[1]="";
    for (int i=0;i<o.size();i++)
    {
        if (o[i]=='+') l++;
        else p[l]+=o[i];
    }
    sort(p,p+2);
    return p[0]+"+"+p[1];
}
int main()
{
  
    cin>>type;
    ifstream conf1("./Regular/config.txt");
    conf1>>tmp;conf1>>tmp;conf1>>tmp;conf1>>tmp;conf1>>tmp;conf1>>tmp;conf1>>tmp;conf1>>tmp;conf1>>tmp;
    conf1>>tmp;conf1>>s1;
    conf1>>tmp;conf1>>s2;
    conf1>>tmp;conf1>>s3;
    ifstream fcFile("./Regular/out/FC.txt");
    while (fcFile >> score) {
        fcFile.get();
        getline(fcFile, name);name=kkk(name);
        Map[name] = max(Map[name], score - s1);
    }
    fcFile.close();
    
  
    ifstream wcFile("./Regular/out/WC.txt");
    while (wcFile >> score) {
        wcFile.get();
        getline(wcFile, name);name=kkk(name);
        Map[name] = max(Map[name], score - s2);
    }
    wcFile.close();
    
  
    ifstream xpFile("./Regular/out/XP.txt");
    while (xpFile >> score) {
        xpFile.get();
        getline(xpFile, name);name=kkk(name);
        Map[name] = max(Map[name], score - s3);
    }
    xpFile.close();
    
    ifstream conf2("./Many/config.txt");
    conf2>>tmp;conf2>>tmp;conf2>>tmp;conf2>>tmp;conf2>>tmp;
    conf2>>tmp;conf2>>s1;
    conf2>>tmp;conf2>>s2;
    ifstream fsFile("./Many/out/FS.txt");
    while (fsFile >> score) {
        fsFile.get();
        getline(fsFile, name);name=kkk(name);
        Map[name] = max(Map[name], score - s1);
    }
    fsFile.close();
    
  
    ifstream hsFile("./Many/out/HS.txt");
    while (hsFile >> score) {
        hsFile.get();
        getline(hsFile, name);name=kkk(name);
        Map[name] = max(Map[name], score - s2);
    }
    hsFile.close();
      
    for (auto x : Map) {
        S.insert(make_pair(-x.second,x.first));
    }
    ofstream outFile("out.txt");
    for (auto x : S) {
        if (type == 1) outFile << -x.first << " " << x.second << "\n";
        if (type == 0) outFile << x.second << "\n";
    }
    outFile.close();
    
    return 0;
}
