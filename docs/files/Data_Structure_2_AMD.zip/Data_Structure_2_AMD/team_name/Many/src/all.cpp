#include<bits/stdc++.h>
#include<windows.h>
using namespace std;
int thread_number;
int two_wc,two_wc_sieve;
int two_fs,two_fs_sieve;
int two_hs,two_hs_sieve;
int xp_sieve,xp_potential_sieve;
int fp_sieve,fp_potential_sieve;
int cp_sieve,cp_potential_sieve;
int dp_sieve,dp_potential_sieve;
int fs_potential_sieve,fspj_potential_sieve;
int hs_potential_sieve,hspj_potential_sieve;
int get_real_fs_score,get_real_hs_score;
int get_real_fspj_score,get_real_hspj_score;
string command="";
void SYSTEM(string s)
{
    system(s.c_str());
}
int main()
{
    cerr<<"Reading config.\n";
    freopen("config.txt","r",stdin);
    cin>>fs_potential_sieve;
    cin>>fspj_potential_sieve;
    cin>>hs_potential_sieve;
    cin>>hspj_potential_sieve;

    cin>>thread_number;

    cin>>two_fs>>two_fs_sieve;
    cin>>two_hs>>two_hs_sieve;

    cin>>get_real_fs_score;
    cin>>get_real_fspj_score;
    cin>>get_real_hs_score;
    cin>>get_real_hspj_score;

    cerr<<"Clear tmp folder.\n";system("rmdir /s /q tmp");system("mkdir tmp");

    cerr<<"merge files.\n";system("merge_files.bat");
    cerr<<"duplicate.\n";system("duplicate.exe ./tmp/new.txt ./file/old.txt ./tmp/new_dup.txt");Sleep(1000);
    //cerr<<"divide new.\n";    system("divide.exe ./tmp/new_dup.txt ./tmp/new_1.txt ./tmp/new_2.txt");

    
    cerr<<"Get useful names.\n";

    cerr<<"FS potential.\n";
    command="SP_potential.exe 0 " +to_string(thread_number) +" ./tmp/new_dup.txt ./tmp/new_tmp.txt";system(command.c_str());
    command="select.exe 10000 "+to_string(fs_potential_sieve)+" ./tmp/new_tmp.txt ./tmp/new_fs.txt ./tmp/new_left.txt";system(command.c_str());


    cerr<<"FSPJ potential.\n";
    command="SP_potential.exe 1 " +to_string(thread_number) +" ./tmp/new_dup.txt ./tmp/new_tmp.txt";system(command.c_str());
    command="select.exe 10000 "+to_string(fspj_potential_sieve)+" ./tmp/new_tmp.txt ./tmp/new_fspj.txt ./tmp/new_left.txt";system(command.c_str());

    
    cerr<<"HS potential.\n";
    command="SP_potential.exe 2 " +to_string(thread_number) +" ./tmp/new_dup.txt ./tmp/new_tmp.txt";system(command.c_str());
    command="select.exe 10000 "+to_string(hs_potential_sieve)+" ./tmp/new_tmp.txt ./tmp/new_hs.txt ./tmp/new_left.txt";system(command.c_str());


    cerr<<"HSPJ potential.\n";
    command="SP_potential.exe 3 " +to_string(thread_number) +" ./tmp/new_dup.txt ./tmp/new_tmp.txt";system(command.c_str());
    command="select.exe 10000 "+to_string(hspj_potential_sieve)+" ./tmp/new_tmp.txt ./tmp/new_hspj.txt ./tmp/new_left.txt";system(command.c_str());



    if (get_real_fs_score)   cerr<<"Real Score FS.\n", system(("RS.exe 0 "+to_string(thread_number)+" ./tmp/new_fs.txt ./tmp/new_fs_score.txt").c_str());
    else                     cerr<<"SP FS.\n",         system("SP.exe 0 ./tmp/new_fs.txt ./tmp/new_fs_score.txt");

    if (get_real_fspj_score) cerr<<"Real Score FSPJ.\n", system(("RS.exe 1 "+to_string(thread_number)+" ./tmp/new_fspj.txt ./tmp/new_fspj_score.txt").c_str());
    else                     cerr<<"SP FSPJ.\n",         system("SP.exe 1 ./tmp/new_fspj.txt ./tmp/new_fspj_score.txt");

    if (get_real_hs_score)   cerr<<"Real Score FS.\n", system(("RS.exe 2 "+to_string(thread_number)+" ./tmp/new_hs.txt ./tmp/new_hs_score.txt").c_str());
    else                     cerr<<"SP FS.\n",         system("SP.exe 2 ./tmp/new_hs.txt ./tmp/new_hs_score.txt");

    if (get_real_hspj_score) cerr<<"Real Score FS.\n", system(("RS.exe 3 "+to_string(thread_number)+" ./tmp/new_hspj.txt ./tmp/new_hspj_score.txt").c_str());
    else                     cerr<<"SP FS.\n",         system("SP.exe 3 ./tmp/new_hspj.txt ./tmp/new_hspj_score.txt");
    


    cerr<<"sort FS.\n";       system("sort.exe 1 ./tmp/new_fs_score.txt ./tmp/new_fs.txt");
    cerr<<"sort FSPJ.\n";       system("sort.exe 1 ./tmp/new_fspj_score.txt ./tmp/new_fspj.txt");
    cerr<<"sort HS.\n";       system("sort.exe 1 ./tmp/new_hs_score.txt ./tmp/new_hs.txt");
    cerr<<"sort HSPJ.\n";       system("sort.exe 1 ./tmp/new_hspj_score.txt ./tmp/new_hspj.txt");


    if (two_fs)
    {
        cerr<<"two_fs new_fs new_fspj\n";command="two_FS.exe 1 "+to_string(thread_number)+" "+to_string(two_fs_sieve)+" ./tmp/new_fs.txt ./tmp/new_fspj.txt ./out/FS.txt";system(command.c_str());
        cerr<<"two_fs new_fs old_fspj\n";command="two_FS.exe 1 "+to_string(thread_number)+" "+to_string(two_fs_sieve)+" ./tmp/new_fs.txt ./file/old_fspj.txt ./out/FS.txt";system(command.c_str());
        cerr<<"two_fs old_fs new_fspj\n";command="two_FS.exe 1 "+to_string(thread_number)+" "+to_string(two_fs_sieve)+" ./file/old_fs.txt ./tmp/new_fspj.txt ./out/FS.txt";system(command.c_str());
    }
    if (two_hs)
    {
        cerr<<"two_hs new_hs new_hspj\n";command="two_HS.exe 1 "+to_string(thread_number)+" "+to_string(two_hs_sieve)+" ./tmp/new_hs.txt ./tmp/new_hspj.txt ./out/HS.txt";system(command.c_str());
        cerr<<"two_hs new_hs old_hspj\n";command="two_HS.exe 1 "+to_string(thread_number)+" "+to_string(two_hs_sieve)+" ./tmp/new_hs.txt ./file/old_hspj.txt ./out/HS.txt";system(command.c_str());
        cerr<<"two_hs old_hs new_hspj\n";command="two_HS.exe 1 "+to_string(thread_number)+" "+to_string(two_hs_sieve)+" ./file/old_hs.txt ./tmp/new_hspj.txt ./out/HS.txt";system(command.c_str());
    }
    


    cerr<<"COPY to file\n";
    
    system("move.exe ./tmp/new_dup.txt ./file/old.txt");
    system("move.exe ./tmp/new_fs.txt ./file/old_fs.txt");
    system("move.exe ./tmp/new_fspj.txt ./file/old_fspj.txt");
    system("move.exe ./tmp/new_hs.txt ./file/old_hs.txt");
    system("move.exe ./tmp/new_hspj.txt ./file/old_hspj.txt");

    
    cerr<<"sort FS.\n";       system("sort.exe 1 ./file/old_fs.txt ./file/old_fs.txt");
    cerr<<"sort FSPJ.\n";     system("sort.exe 1 ./file/old_fspj.txt ./file/old_fspj.txt");
    cerr<<"sort HS.\n";       system("sort.exe 1 ./file/old_hs.txt ./file/old_hs.txt");
    cerr<<"sort HSPJ.\n";     system("sort.exe 1 ./file/old_hspj.txt ./file/old_hspj.txt");
    //system("type ./tmp/new.txt >> ./file/old.txt");
    
    cerr<<"COPY to new\n";

    system("move.exe ./tmp/new_dup.txt ./new/new.txt");
    system("move.exe ./tmp/new_fs.txt ./new/new_fs.txt");
    system("move.exe ./tmp/new_fspj.txt ./new/new_fspj.txt");
    system("move.exe ./tmp/new_hs.txt ./new/new_hs.txt");
    system("move.exe ./tmp/new_hspj.txt ./new/new_hspj.txt");

    
    cerr<<"sort FS.\n";       system("sort.exe 1 ./new/new_fs.txt ./new/new_fs.txt");
    cerr<<"sort FSPJ.\n";     system("sort.exe 1 ./new/new_fspj.txt ./new/new_fspj.txt");
    cerr<<"sort HS.\n";       system("sort.exe 1 ./new/new_hs.txt ./new/new_hs.txt");
    cerr<<"sort HSPJ.\n";     system("sort.exe 1 ./new/new_hspj.txt ./new/new_hspj.txt");

}