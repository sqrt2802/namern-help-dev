#include<bits/stdc++.h>
#include<windows.h>
using namespace std;
unordered_set<string> S;
string s;
int n;

char c;
int main(int argc, char* argv[]) {
    
    if (argc != 4) {
        std::cerr << "Usage: " << argv[0] << " <input_file_1> <intput_file_2> <output_file>" << std::endl;
        return 1;
    }
    freopen(argv[2],"r",stdin);
    cerr<<"Removal of duplicates......\n";
    
    cerr<<"Reading all.txt......\n";
    c=getchar();
    while(1)
    {
        if (c=='\n' || c=='\r' || ((int)(c)==255 || (int)(c)==-1))
        {
            if (s!="\n" && s!="" && s!="\r")
            S.insert(s);
            n++;if (n%10000==0) cerr<<"n="<<n<<"\n";
            s="";
            if ((int)(c)==255 || (int)(c)==-1) break;
        } else s=s+c;
        c=getchar();
        //cerr<<"n="<<n<<" c="<<(int)c<<"\n";
    }
    freopen(argv[1],"r",stdin);
    freopen(argv[3],"w",stdout);
    cerr<<"Reading new.txt......\n";
    n=0;
    c=getchar();
    while(1)
    {
        if (c=='\n' || c=='\r' || ((int)(c)==255 || (int)(c)==-1))
        {
            if (s!="\n" && s!="" && s!="\r")
            if (S.find(s)==S.end())
            {
                cout<<s<<"\n";
                S.insert(s);
            }
            n++;if (n%10000==0) cerr<<"n="<<n<<"\n";
            s="";
            if ((int)(c)==255 || (int)(c)==-1) break;
        } else s=s+c;
        c=getchar();
    }
    fflush(stdout);
}