#include<bits/stdc++.h>
#include<windows.h>
using namespace std;
const int N=3000005;
struct Name{string s;double qp;};
bool cmp(Name x,Name y){return x.qp==y.qp?x.s>y.s:x.qp>y.qp;}
bool cmp2(Name x,Name y){return x.s==y.s?x.qp>y.qp:x.s>y.s;}
Name a[N];
int n,cnt;
int type;
string s;
double sieve_1,sieve_2;
double x,y;
int main(int argc, char* argv[]) 
{
    if (argc != 6) {
        std::cerr << "Usage: " << argv[0] << " <sieve_1> <sieve_2> <input_file> <output_file_1> <output_file_2>" << std::endl;
        return 1;
    }
    sieve_1 = std::atoi(argv[1]);
    sieve_2 = std::atoi(argv[2]);
    cerr<<"sieve 1="<<sieve_1<<" sieve 2 ="<<sieve_2<<"\n";
    freopen(argv[3],"r",stdin);
    FILE *fp1=fopen(argv[4],"w");
    FILE *fp2=fopen(argv[5],"w");
    double x=0;
    int n=0;
    while (cin>>x>>y)
    {
        n++;
        if (n%10000==0) cerr<<"cnt="<<n<<"\n";
        getchar();getline(cin,s);
        if (x>=sieve_1 || y>=sieve_2) fprintf(fp1,"%s\n",s.c_str());
        else fprintf(fp2,"%s\n",s.c_str());
    }
    fflush(fp1);fflush(fp2);
}