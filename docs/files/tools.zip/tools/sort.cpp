#include<bits/stdc++.h>
using namespace std;
const int N=10000005;
struct Name{string s;double qp;};

bool cmp0(Name x,Name y){return x.qp==y.qp?x.s>y.s:x.qp<y.qp;}
bool cmp(Name x,Name y){return x.qp==y.qp?x.s>y.s:x.qp>y.qp;}
bool cmp2(Name x,Name y){return x.s==y.s?x.qp>y.qp:x.s>y.s;}
Name a[N];
int n,cnt;
int type;
int main()
{
    cin>>type;
    freopen("input.txt","r",stdin);
    freopen("sort.txt","w",stdout);
    cin>>n;
    cerr<<"n="<<n<<"\n";
    for (int i=1;i<=n;i++) 
    {
        double x=0,y=0;

        for (int j=1;j<=1;j++) {cin>>x;a[i].qp+=x;getchar();getline(cin,a[i].s);}
        for (int j=1;j<=0;j++) {cin>>x;a[i].qp+=y;getchar();getline(cin,a[i].s);}
        for (int j=1;j<=0;j++) {cin>>x;a[i].qp+=x;getchar();getline(cin,a[i].s);}
        for (int j=1;j<=0;j++) {cin>>x;a[i].qp+=y;getchar();getline(cin,a[i].s);}
        for (int j=1;j<=0;j++) {cin>>x;a[i].qp+=x;getchar();getline(cin,a[i].s);}
        for (int j=1;j<=0;j++) {cin>>x;a[i].qp+=y;getchar();getline(cin,a[i].s);}
        if (a[i].qp>2000) {cnt++;if (cnt%10000==0) cerr<<cnt<<"\n";}
    }
    if (type==-1) 
    sort(a+1,a+n+1,cmp0); else
    sort(a+1,a+n+1,cmp);
    //sort(a+1,a+n+1,cmp2);
    for (int i=1;i<=n;i++) 
    //if (a[i].s!=a[i-1].s)
    if (a[i].s!=a[i-1].s || a[i].qp!=a[i-1].qp)  
    {
        if (type==1) printf("%.3lf ",a[i].qp);
        cout<<a[i].s<<"\n";
    }
}